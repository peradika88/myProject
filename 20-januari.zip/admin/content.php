<?php
/* panggil file database.php untuk koneksi ke database */
require_once "../config/database.php";
/* panggil file fungsi tambahan */
require_once "../config/fungsi_tanggal.php";
require_once "../config/fungsi_rupiah.php";


// fungsi untuk pengecekan status login user 
// jika user belum login, alihkan ke halaman login dan tampilkan message = 1
if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
    echo "<meta http-equiv='refresh' content='0; url=login.php?alert=1'>";
} // jika user sudah login, maka jalankan perintah untuk pemanggilan file halaman konten
else {
    // jika halaman konten yang dipilih home, panggil file view home
    if ($_GET['module'] == 'home') {
        include "modules/beranda/view.php";
    } // jika halaman konten yang dipilih guru, panggil file view guru
    elseif ($_GET['module'] == 'guru') {
        include "modules/guru/view.php";
    } // jika halaman konten yang dipilih form guru, panggil file form guru
    elseif ($_GET['module'] == 'form_guru') {
        include "modules/guru/form.php";
    }
    // -----------------------------------------------------------------------------

    // jika halaman konten yang dipilih staff, panggil file view sekolah
    elseif ($_GET['module'] == 'staff') {
        include "modules/staff/view.php";
    } // jika halaman konten yang dipilih form sekolah, panggil file form staff
    elseif ($_GET['module'] == 'form_staff') {
        include "modules/staff/form.php";
    }
    // -----------------------------------------------------------------------------
	
	
    // jika halaman konten yang dipilih customer, panggil file data customer
    elseif ($_GET['module'] == 'customer') {
        include "modules/customer/view.php";
    } // jika halaman konten yang  dipilih form customer, panggil file form data customer
    elseif ($_GET['module'] == 'form_customer') {
        include "modules/customer/form.php";
    }
    // -----------------------------------------------------------------------------

    // jika halaman konten yang dipilih koordinator, panggil file view sekolah
    elseif ($_GET['module'] == 'koordinator') {
        include "modules/koordinator/view.php";
    } // jika halaman konten yang dipilih form sekolah, panggil file form koordinator
    elseif ($_GET['module'] == 'form_koordinator') {
        include "modules/koordinator/form.php";
    }
    // -----------------------------------------------------------------------------


    // jika halaman konten yang dipilih sekolah, panggil file view sekolah
    elseif ($_GET['module'] == 'sekolah') {
        include "modules/sekolah/view.php";
    } // jika halaman konten yang dipilih form sekolah, panggil file form sekolah
    elseif ($_GET['module'] == 'form_sekolah') {
        include "modules/sekolah/form.php";
    }
    // -----------------------------------------------------------------------------
    elseif ($_GET['module'] == 'jadwal_guru') {
        include "modules/jadwal/view.php";
    }
    elseif ($_GET['module'] == 'form_jadwal_guru') {
        include "modules/jadwal/form.php";
    }
    // jika halaman konten yang dipilih gaji staff, panggil file view gaji staff
    elseif ($_GET['module'] == 'gaji_staff') {
        include "modules/gaji-staff/view.php";
    } // jika halaman konten yang dipilih form gaji staff, panggil file form gaji staff
    elseif ($_GET['module'] == 'form_gaji_staff') {
        include "modules/gaji-staff/form.php";
    }
    // -----------------------------------------------------------------------------

    // jika halaman konten yang dipilih gaji guru, panggil file view gaji guru
    elseif ($_GET['module'] == 'gaji_guru') {
        include "modules/gaji-guru/view.php";
    } // jika halaman konten yang dipilih form gaji guru, panggil file form gaji guru
    elseif ($_GET['module'] == 'form_gaji_guru') {
        include "modules/gaji-guru/form.php";
    }
	
	
	
	// -----------------------------------------------------------------------------LAPORAN DCP

    // jika halaman konten yang dipilih =, panggil file view lap dcp
    elseif ($_GET['module'] == 'lap_dcp') {
        include "modules/lap-dcp/view.php";
    } // jika halaman konten yang dipilih form =, panggil file form lap-dcp
    elseif ($_GET['module'] == 'form_lap_dcp') {
        include "modules/lap-dcp/form.php";
    } // jika halaman konten yang dipilih form =, panggil file cetak lap-dcp
    elseif ($_GET['module'] == 'cetak_lap_dcp') {
        include "modules/lap-dcp/view-cetak.php";
    }
	
	// -----------------------------------------------------------------------------LAPORAN ABCD

    // jika halaman konten yang dipilih=, panggil file view lap abcd
    elseif ($_GET['module'] == 'lap_abcd') {
        include "modules/lap-abcd/view.php";
    } // jika halaman konten yang dipilih form =, panggil file form lap-abcd
    elseif ($_GET['module'] == 'form_lap_abcd') {
        include "modules/lap-abcd/form.php";
    } // jika halaman konten yang dipilih form =, panggil file cetak lap-abcd
    elseif ($_GET['module'] == 'cetak_lap_abcd') {
        include "modules/lap-abcd/view-cetak.php";
    }
    // -----------------------------------------------------------------------------
    // jika halaman konten yang dipilih laporan lap_mengajar_guru, panggil file view laporan lap_mengajar_guru
    elseif ($_GET['module'] == 'lap_mengajar_guru') {
        include "modules/lap-mengajar-guru/view.php";
    }
    // jika halaman konten yang dipilih laporan lap_gaji_staff, panggil file view laporan lap_gaji_staff
    elseif ($_GET['module'] == 'lap_gaji_staff') {
        include "modules/lap-gaji-staff/view.php";
    }
    // -----------------------------------------------------------------------------

    // jika halaman konten yang dipilih laporan lap_gaji_guru, panggil file view laporan lap_gaji_guru
    elseif ($_GET['module'] == 'lap_gaji_guru') {
        include "modules/lap-gaji-guru/view.php";
    }
    // -----------------------------------------------------------------------------
    // jika halaman konten yang dipilih laporan lap_absensi_guru, panggil file view laporan lap_absensi_guru
    elseif ($_GET['module'] == 'lap_absensi_guru') {
        include "modules/lap-absensi-guru/view.php";
    } // -----------------------------------------------------------------------------
    // jika halaman konten yang dipilih user, panggil file view user
    elseif ($_GET['module'] == 'user') {
        include "modules/user/view.php";
    } // jika halaman konten yang dipilih form user, panggil file form user
    elseif ($_GET['module'] == 'form_user') {
        include "modules/user/form.php";
    }
    // -----------------------------------------------------------------------------

    // jika halaman konten yang dipilih profil, panggil file view profil
    elseif ($_GET['module'] == 'profil') {
        include "modules/profil/view.php";
    } // jika halaman konten yang dipilih form profil, panggil file form profil
    elseif ($_GET['module'] == 'form_profil') {
        include "modules/profil/form.php";
    }
    // -----------------------------------------------------------------------------

    // jika halaman konten yang dipilih password, panggil file view password
    elseif ($_GET['module'] == 'password') {
        include "modules/password/view.php";
    }
}
?>