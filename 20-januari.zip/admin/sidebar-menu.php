<?php
// fungsi pengecekan level untuk menampilkan menu sesuai dengan hak akses
// jika hak akses = Super Admin, tampilkan menu
if ($_SESSION['hak_akses'] == 'Admin') { ?>
    <!-- sidebar menu start -->
    <ul class="sidebar-menu">
        <li class="header">MAIN MENU</li>

        <?php
        // fungsi untuk pengecekan menu aktif
        // jika menu home dipilih, menu home aktif
        if ($_GET["module"] == "home") { ?>
            <li class="active">
                <a href="?module=home"><i class="fa fa-home"></i> Beranda </a>
            </li>
            <?php
        } // jika tidak, menu home tidak aktif
        else { ?>
            <li>
                <a href="?module=home"><i class="fa fa-home"></i> Beranda </a>
            </li>
            <?php
        }

        // jika menu guru dipilih, menu guru aktif
        if ($_GET["module"] == "guru" || $_GET["module"] == "form_guru") { ?>
            <li class="active">
                <a href="?module=guru"><i class="fa fa-group"></i> Data Deputy Manager</a>
            </li>
            <?php
        } // jika tidak, menu guru tidak aktif
        else { ?>
            <li>
                <a href="?module=guru"><i class="fa fa-group"></i> Data Deputy Manager</a>
            </li>
            <?php
        }

        // jika menu staff dipilih, menu staff aktif
        if ($_GET["module"] == "staff" || $_GET["module"] == "form_staff") { ?>
            <li class="active">
                <a href="?module=staff"><i class="fa fa-group"></i> Data Store Manager</a>
            </li>
            <?php
        } // jika tidak, menu staff tidak aktif
        else { ?>
            <li>
                <a href="?module=staff"><i class="fa fa-group"></i> Data Store Manager</a>
            </li>
            <?php
        }


        // jika menu koordinator dipilih, menu koordinator aktif
        if ($_GET["module"] == "koordinator" || $_GET["module"] == "form_koordinator") { ?>
            <li class="active">
                <a href="?module=koordinator"><i class="fa fa-group"></i> Data Regional Manager</a>
            </li>
            <?php
        } // jika tidak, menu koordinator tidak aktif
        else { ?>
            <li>
                <a href="?module=koordinator"><i class="fa fa-group"></i> Data Regional Manager</a>
            </li>
            <?php
        }

        // jika menu sekolah dipilih, menu sekolah aktif
        if ($_GET["module"] == "sekolah" || $_GET["module"] == "form_sekolah") { ?>
            <li class="active">
                <a href="?module=sekolah"><i class="glyphicon glyphicon-briefcase"></i> Data Store</a>
            </li>
            <?php
        } // jika tidak, menu sekolah tidak aktif
        else { ?>
            <li>
                <a href="?module=sekolah"><i class="glyphicon glyphicon-briefcase"></i> Data Store</a>
            </li>
            <?php
        }
		
		 // jika menu sekolah dipilih, menu customer aktif
        if ($_GET["module"] == "customer" || $_GET["module"] == "form_customer") { ?>
            <li class="active">
                <a href="?module=customer"><i class="glyphicon glyphicon-credit-card"></i> Data Customer</a>
            </li>
            <?php
        } // jika tidak, menu sekolah tidak aktif
        else { ?>
            <li>
                <a href="?module=customer"><i class="glyphicon glyphicon-credit-card"></i> Data Customer</a>
            </li>
            <?php
        }
        // jika menu jadwal dipilih, menu jadwal aktif
        if ($_GET["module"] == "jadwal_guru" || $_GET["module"] == "form_jadwal_guru") { ?>
            <li class="active">
                <a href="?module=jadwal_guru"><i class="fa fa-files-o"></i> File</a>
            </li>
            <?php
        } // jika tidak, menu jadwal tidak aktif
        else { ?>
            <li>
                <a href="?module=jadwal_guru"><i class="fa fa-files-o"></i> File</a>
            </li>
            <?php
        }

        // jika menu Penggajian Staff dipilih, menu Penggajian Staff aktif
        /* if ($_GET["module"] == "gaji_staff" || $_GET["module"] == "form_gaji_staff") { ?>
           <li class="active treeview">
                <a href="javascript:void(0);">
                    <i class="fa fa-calculator"></i> <span>Transaksi Pengajian</span> <i
                            class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class="active"><a href="?module=gaji_staff"><i class="fa fa-circle-o"></i> Penggajian Staff</a>
                    </li>
                    <li><a href="?module=gaji_guru"><i class="fa fa-circle-o"></i> Penggajian Guru</a></li>
                </ul>
            </li>
            <?php
        } // jika menu Penggajian Guru dipilih, menu Penggajian Guru aktif
        elseif ($_GET["module"] == "gaji_guru" || $_GET["module"] == "form_gaji_guru") { ?>
            <li class="active treeview">
                <a href="javascript:void(0);">
                    <i class="fa fa-calculator"></i> <span>Transaksi Pengajian</span> <i
                            class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="?module=gaji_staff"><i class="fa fa-circle-o"></i> Penggajian Staff</a></li>
                    <li class="active"><a href="?module=gaji_guru"><i class="fa fa-circle-o"></i> Penggajian Guru</a>
                    </li>
                </ul>
            </li>
            <?php
        } // jika menu Transaksi tidak dipilih, menu Transaksi tidak aktif
        else { ?>
            <li class="treeview">
                <a href="javascript:void(0);">
                    <i class="fa fa-calculator"></i> <span>Transaksi Pengajian</span> <i
                            class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="?module=gaji_staff"><i class="fa fa-circle-o"></i> Penggajian Staff</a></li>
                    <li><a href="?module=gaji_guru"><i class="fa fa-circle-o"></i> Penggajian Guru</a></li>
                </ul>
            </li>
            <?php
        }
		
        // jika menu Gaji Staff dipilih, menu Gaji Staff aktif
        if ($_GET["module"] == "lap_gaji_staff") { ?>
            <li class="active treeview">
                <a href="javascript:void(0);">
                    <i class="fa fa-money"></i> <span>Laporan Gaji</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class="active"><a href="?module=lap_gaji_staff"><i class="fa fa-circle-o"></i> Gaji Staff</a>
                    </li>
                    <li><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> Gaji Guru</a></li>
                </ul>
            </li>
            <?php
        } // jika menu Gaji Guru dipilih, menu Gaji Guru aktif
        elseif ($_GET["module"] == "lap_gaji_guru") { ?>
            <li class="active treeview">
                <a href="javascript:void(0);">
                    <i class="fa fa-money"></i> <span>Laporan Gaji</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="?module=lap_gaji_staff"><i class="fa fa-circle-o"></i> Gaji Staff</a></li>
                    <li class="active"><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> Gaji Guru</a></li>
                </ul>
            </li>
            <?php
        } // jika menu Laporan tidak dipilih, menu Laporan tidak aktif
        else { ?>
            <li class="treeview">
                <a href="javascript:void(0);">
                    <i class="fa fa-money"></i> <span>Laporan Gaji</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="?module=lap_gaji_staff"><i class="fa fa-circle-o"></i> Gaji Staff</a></li>
                    <li><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> Gaji Guru</a></li>
                </ul>
            </li>
            <?php
        }
        // jika menu lap_absensi_guru dipilih, menu Lap aktif
        if ($_GET["module"] == "lap_mengajar_guru") { ?>
            <li class="active">
                <a href="?module=lap_mengajar_guru"><i class="fa fa-file"></i> Laporan Mengajar</a>
            </li>
            <?php
        } // jika tidak, menu lap_absensi_guru tidak aktif
        else { ?>
            <li>
                <a href="?module=lap_mengajar_guru"><i class="fa fa-file"></i> Laporan Mengajar</a>
            </li>
            <?php
        }
		*/
        // jika menu lap_absensi_guru dipilih, menu Lap aktif
        if ($_GET["module"] == "laporan") { ?>
            <li class="active treeview">
                <a href="javascript:void(0);">
                    <i class="fa fa-file-text-o"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class="active"><a href="?module=lap_gaji_staff"><i class="fa fa-circle-o"></i> ABCD Class</a></li>
                    <li><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> Outstanding PO</a></li>
					<li><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> Outstanding PO</a></li>
					<li><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> Inventory Movement</a></li>
					<li><a href="?module=lap_dcp"><i class="fa fa-circle-o"></i> Delivery To Customer Performance</a></li>
					<li><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> Replenishment Calculation</a></li>
                </ul>
            </li>
            <?php
        } // jika tidak, menu lap_absensi_guru tidak aktif
        else { ?>
            <li>
               <a href="javascript:void(0);">
                    <i class="fa fa-file-text-o"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class="active"><a href="?module=lap_abcd"><i class="fa fa-circle-o"></i> ABCD Class</a></li>
                    <li><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> Outstanding PO</a></li>
					<li><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> Outstanding PO</a></li>
					<li><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> Inventory Movement</a></li>
					<li><a href="?module=lap_dcp"><i class="fa fa-circle-o"></i> Delivery To Customer Performance</a></li>
					<li><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> Replenishment Calculation</a></li>
                </ul>
            </li>
            <?php
        }
		
		// jika menu lap_absensi_guru dipilih, menu Lap aktif
        if ($_GET["module"] == "laporan") { ?>
            <li class="active treeview">
                <a href="javascript:void(0);">
                    <i class="glyphicon glyphicon-flag"></i> <span>Rank</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class="active"><a href="?module=lap_gaji_staff"><i class="fa fa-circle-o"></i> By Store</a></li>
                    <li><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> By Category</a></li>
                </ul>
            </li>
            <?php
        } // jika tidak, menu lap_absensi_guru tidak aktif
        else { ?>
            <li>
               <a href="javascript:void(0);">
                    <i class="glyphicon glyphicon-flag"></i> <span>Rank</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                     <li class="active"><a href="?module=lap_gaji_staff"><i class="fa fa-circle-o"></i> By Store</a></li>
                    <li><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> By Category</a></li>
                </ul>
            </li>
            <?php
        }

        // jika menu ubah user dipilih, menu ubah user aktif
        if ($_GET["module"] == "user") { ?>
            <li class="active">
                <a href="?module=user"><i class="fa fa-user"></i> Managemen User</a>
            </li>
            <?php
        } // jika tidak, menu ubah user tidak aktif
        else { ?>
            <li>
                <a href="?module=user"><i class="fa fa-user"></i> Managemen User</a>
            </li>
            <?php
        }

        // jika menu ubah password dipilih, menu ubah password aktif
        if ($_GET["module"] == "password") { ?>
            <li class="active">
                <a href="?module=password"><i class="fa fa-lock"></i> Ganti Password</a>
            </li>
            <?php
        } // jika tidak, menu ubah password tidak aktif
        else { ?>
            <li>
                <a href="?module=password"><i class="fa fa-lock"></i> Ganti Password</a>
            </li>
            <?php
        }

        ?>
    </ul>
    <!--sidebar menu end-->
    <?php
}
if ($_SESSION['hak_akses'] == 'Direktur') { ?>
    <!-- sidebar menu start -->
    <ul class="sidebar-menu">
        <li class="header">MAIN MENU</li>

        <?php
        // fungsi untuk pengecekan menu aktif
        // jika menu home dipilih, menu home aktif
        if ($_GET["module"] == "home") { ?>
            <li class="active">
                <a href="?module=home"><i class="fa fa-home"></i> Beranda </a>
            </li>
            <?php
        } // jika tidak, menu home tidak aktif
        else { ?>
            <li>
                <a href="?module=home"><i class="fa fa-home"></i> Beranda </a>
            </li>
            <?php
        }

        // jika menu Gaji Staff dipilih, menu Gaji Staff aktif
        if ($_GET["module"] == "lap_gaji_staff") { ?>
            <li class="active treeview">
                <a href="javascript:void(0);">
                    <i class="fa fa-money"></i> <span>Laporan Gaji</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class="active"><a href="?module=lap_gaji_staff"><i class="fa fa-circle-o"></i> Gaji Staff</a>
                    </li>
                    <li><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> Gaji Guru</a></li>
                </ul>
            </li>
            <?php
        } // jika menu Gaji Guru dipilih, menu Gaji Guru aktif
        elseif ($_GET["module"] == "lap_gaji_guru") { ?>
            <li class="active treeview">
                <a href="javascript:void(0);">
                    <i class="fa fa-money"></i> <span>Laporan Gaji</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="?module=lap_gaji_staff"><i class="fa fa-circle-o"></i> Gaji Staff</a></li>
                    <li class="active"><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> Gaji Guru</a></li>
                </ul>
            </li>
            <?php
        } // jika menu Laporan tidak dipilih, menu Laporan tidak aktif
        else { ?>
            <li class="treeview">
                <a href="javascript:void(0);">
                    <i class="fa fa-money"></i> <span>Laporan Gaji</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="?module=lap_gaji_staff"><i class="fa fa-circle-o"></i> Gaji Staff</a></li>
                    <li><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> Gaji Guru</a></li>
                </ul>
            </li>
            <?php
        }
        if ($_GET["module"] == "lap_mengajar_guru") { ?>
            <li class="active">
                <a href="?module=lap_mengajar_guru"><i class="fa fa-file"></i> Laporan Mengajar</a>
            </li>
            <?php
        } // jika tidak, menu lap_absensi_guru tidak aktif
        else { ?>
            <li>
                <a href="?module=lap_mengajar_guru"><i class="fa fa-file"></i> Laporan Mengajar</a>
            </li>
            <?php
        }
        // jika menu lap_absensi_guru dipilih, menu Lap aktif
        if ($_GET["module"] == "lap_absensi_guru") { ?>
            <li class="active">
                <a href="?module=lap_absensi_guru"><i class="fa fa-file"></i> Laporan Absensi</a>
            </li>
            <?php
        } // jika tidak, menu lap_absensi_guru tidak aktif
        else { ?>
            <li>
                <a href="?module=lap_absensi_guru"><i class="fa fa-file"></i> Laporan Absensi</a>
            </li>
            <?php
        }
        // jika menu ubah password dipilih, menu ubah password aktif
        if ($_GET["module"] == "password") { ?>
            <li class="active">
                <a href="?module=password"><i class="fa fa-lock"></i> Ganti Password</a>
            </li>
            <?php
        } // jika tidak, menu ubah password tidak aktif
        else { ?>
            <li>
                <a href="?module=password"><i class="fa fa-lock"></i> Ganti Password</a>
            </li>
            <?php
        }

        ?>
    </ul>
    <!--sidebar menu end-->
    <?php
}
// jika hak akses = Bagian Keuangan, tampilkan menu
if ($_SESSION['hak_akses'] == 'Keuangan') { ?>
    <!-- sidebar menu start -->
    <ul class="sidebar-menu">
        <li class="header">MAIN MENU</li>

        <?php
        // fungsi untuk pengecekan menu aktif
        // jika menu home dipilih, menu home aktif
        if ($_GET["module"] == "home") { ?>
            <li class="active">
                <a href="?module=home"><i class="fa fa-home"></i> Beranda </a>
            </li>
            <?php
        } // jika tidak, menu home tidak aktif
        else { ?>
            <li>
                <a href="?module=home"><i class="fa fa-home"></i> Beranda </a>
            </li>
            <?php
        }

        // jika menu Penggajian Staff dipilih, menu Penggajian Staff aktif
        if ($_GET["module"] == "gaji_staff" || $_GET["module"] == "form_gaji_staff") { ?>
            <li class="active treeview">
                <a href="javascript:void(0);">
                    <i class="fa fa-calculator"></i> <span>Transaksi</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class="active"><a href="?module=gaji_staff"><i class="fa fa-circle-o"></i> Penggajian Staff</a>
                    </li>
                    <li><a href="?module=gaji_guru"><i class="fa fa-circle-o"></i> Penggajian Guru</a></li>
                </ul>
            </li>
            <?php
        } // jika menu Penggajian Guru dipilih, menu Penggajian Guru aktif
        elseif ($_GET["module"] == "gaji_guru" || $_GET["module"] == "form_gaji_guru") { ?>
            <li class="active treeview">
                <a href="javascript:void(0);">
                    <i class="fa fa-calculator"></i> <span>Transaksi</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="?module=gaji_staff"><i class="fa fa-circle-o"></i> Penggajian Staff</a></li>
                    <li class="active"><a href="?module=gaji_guru"><i class="fa fa-circle-o"></i> Penggajian Guru</a>
                    </li>
                </ul>
            </li>
            <?php
        } // jika menu Transaksi tidak dipilih, menu Transaksi tidak aktif
        else { ?>
            <li class="treeview">
                <a href="javascript:void(0);">
                    <i class="fa fa-calculator"></i> <span>Transaksi</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="?module=gaji_staff"><i class="fa fa-circle-o"></i> Penggajian Staff</a></li>
                    <li><a href="?module=gaji_guru"><i class="fa fa-circle-o"></i> Penggajian Guru</a></li>
                </ul>
            </li>
            <?php
        }

        // jika menu Gaji Staff dipilih, menu Gaji Staff aktif
        if ($_GET["module"] == "lap_gaji_staff") { ?>
            <li class="active treeview">
                <a href="javascript:void(0);">
                    <i class="fa fa-money"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class="active"><a href="?module=lap_gaji_staff"><i class="fa fa-circle-o"></i> Gaji Staff</a>
                    </li>
                    <li><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> Gaji Guru</a></li>
                </ul>
            </li>
            <?php
        } // jika menu Gaji Guru dipilih, menu Gaji Guru aktif
        elseif ($_GET["module"] == "lap_gaji_guru") { ?>
            <li class="active treeview">
                <a href="javascript:void(0);">
                    <i class="fa fa-money"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="?module=lap_gaji_staff"><i class="fa fa-circle-o"></i> Gaji Staff</a></li>
                    <li class="active"><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> Gaji Guru</a></li>
                </ul>
            </li>
            <?php
        } // jika menu Laporan tidak dipilih, menu Laporan tidak aktif
        else { ?>
            <li class="treeview">
                <a href="javascript:void(0);">
                    <i class="fa fa-money"></i> <span>Laporan</span> <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="?module=lap_gaji_staff"><i class="fa fa-circle-o"></i> Gaji Staff</a></li>
                    <li><a href="?module=lap_gaji_guru"><i class="fa fa-circle-o"></i> Gaji Guru</a></li>
                </ul>
            </li>
            <?php
        }

        // jika menu ganti password dipilih, menu ganti password aktif
        if ($_GET["module"] == "password") { ?>
            <li class="active">
                <a href="?module=password"><i class="fa fa-lock"></i> Ganti Password</a>
            </li>
            <?php
        } // jika tidak, menu ubah password tidak aktif
        else { ?>
            <li>
                <a href="?module=password"><i class="fa fa-lock"></i> Ganti Password</a>
            </li>
            <?php
        }

        ?>
    </ul>
    <!--sidebar menu end-->
    <?php
}
?>