<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        <i class="fa fa-graduation-cap icon-title"></i> Data Customer

        <a class="btn btn-primary btn-social pull-right" href="?module=form_customer&form=add" title="Tambah Data"
           data-toggle="tooltip">
            <i class="fa fa-plus"></i> Tambah
        </a>
    </h1>

</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">

            <?php
            // fungsi untuk menampilkan pesan
            // jika alert = "" (kosong)
            // tampilkan pesan "" (kosong)
            if (empty($_GET['alert'])) {
                echo "";
            }
            // jika alert = 1
            // tampilkan pesan Sukses "Customer baru berhasil disimpan"
            elseif ($_GET['alert'] == 1) {
                echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Sukses!</h4>
              Customer baru berhasil disimpan.
            </div>";
            }
            // jika alert = 2
            // tampilkan pesan Sukses "Customer berhasil diubah"
            elseif ($_GET['alert'] == 2) {
                echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Sukses!</h4>
              Customer berhasil diubah.
            </div>";
            }
            // jika alert = 3
            // tampilkan pesan Sukses "Customer berhasil dihapus"
            elseif ($_GET['alert'] == 3) {
                echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Sukses!</h4>
			  Customer berhasil dihapus.
            </div>";
            }
            ?>

            <div class="box box-primary">
                <div class="box-body">
                    <!-- tampilan tabel sekolah -->
                    <table id="dataTables1" class="table table-bordered table-striped table-hover">
                        <!-- tampilan tabel header -->
                        <thead>
                        <tr>
                            <th class="center">No.</th>
                            <th class="center">ID Customer</th>
                            <th class="center">No Member</th>
                            <th class="center">Nama Customer</th>
                            <th class="center">No. Telepon</th>
                            <th></th>
                        </tr>
                        </thead>
                        <!-- tampilan tabel body -->
                        <tbody>
                        <?php
                        $no = 1;
                        // fungsi query untuk menampilkan data dari tabel customer
                        $query = mysqli_query($mysqli, "SELECT * FROM tb_customer ORDER BY id_customer DESC")
                        or die('Ada kesalahan pada query tampil Data Customer: ' . mysqli_error($mysqli));

                        // tampilkan data
                        while ($data = mysqli_fetch_assoc($query)) {
                            // menampilkan isi tabel dari database ke tabel di aplikasi
                            echo "<tr>
                      <td width='40' class='center'>$no</td>
                      <td width='40'>$data[id_customer]</td>
                      <td width='40'>$data[no_member]</td>
					  <td width='300'>$data[nama]</td>
                      <td width='50'>$data[tlp]</td>
                      <td class='center' width='80'>
                        <div>
                          <a data-toggle='tooltip' data-placement='top' title='Ubah' style='margin-right:5px' class='btn btn-primary btn-sm' href='?module=form_customer&form=edit&id=$data[id_customer]'>
                              <i style='color:#fff' class='glyphicon glyphicon-edit'></i>
                          </a>";
                            ?>
                            <a data-toggle="tooltip" data-placement="top" title="Hapus" class="btn btn-danger btn-sm"
                               href="modules/customer/proses.php?act=delete&id=<?php echo $data['id_customer']; ?>"
                               onclick="return confirm('Anda yakin ingin menghapus customer <?php echo $data['nama']; ?> ?');">
                                <i style="color:#fff" class="glyphicon glyphicon-trash"></i>
                            </a>
                            <?php
                            echo "    </div>
                      </td>
                    </tr>";
                            $no++;
                        }
                        ?>
                        </tbody>
                    </table>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div><!--/.col -->
    </div>   <!-- /.row -->
</section><!-- /.content