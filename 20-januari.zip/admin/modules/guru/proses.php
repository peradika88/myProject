<?php
session_start();

// Panggil koneksi database.php untuk koneksi database
require_once "../../../config/database.php";

// fungsi untuk pengecekan status login admin
// jika admin belum login, alihkan ke halaman login dan tampilkan pesan = 1
if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
    echo "<meta http-equiv='refresh' content='0; url=login.php?alert=1'>";
} // jika admin sudah login, maka jalankan perintah untuk insert dan update
else {
    // insert data
    if ($_GET['act'] == 'insert') {
        if (isset($_POST['simpan'])) {
            if (isset($_POST['nip'])) {
                // ambil data hasil submit dari form
                $nip = mysqli_real_escape_string($mysqli, trim($_POST['nip']));
                $password = md5(mysqli_real_escape_string($mysqli, trim($_POST['password'])));
                $nama_lengkap = mysqli_real_escape_string($mysqli, trim($_POST['nama_lengkap']));
                $tempat_lahir = mysqli_real_escape_string($mysqli, trim($_POST['tempat_lahir']));

                $tanggal = mysqli_real_escape_string($mysqli, trim($_POST['tanggal_lahir']));
                $tgl = explode('-', $tanggal);
                $tanggal_lahir = $tgl[2] . "-" . $tgl[1] . "-" . $tgl[0];

                $jenis_kelamin = mysqli_real_escape_string($mysqli, trim($_POST['jenis_kelamin']));
                $status_perkawinan = mysqli_real_escape_string($mysqli, trim($_POST['status_perkawinan']));
                $alamat_lengkap = mysqli_real_escape_string($mysqli, trim($_POST['alamat_lengkap']));
                $no_telepon = mysqli_real_escape_string($mysqli, trim($_POST['no_telepon']));
                $agama = mysqli_real_escape_string($mysqli, trim($_POST['agama']));
                $honor_session       = str_replace('.', '', trim($_POST['honor_session']));

                $nama_file = $_FILES['foto']['name'];
                $ukuran_file = $_FILES['foto']['size'];
                $tipe_file = $_FILES['foto']['type'];
                $tmp_file = $_FILES['foto']['tmp_name'];

                // tentuka extension yang diperbolehkan
                $allowed_extensions = array('jpg', 'jpeg', 'png');

                // Set path folder tempat menyimpan gambarnya
                $path_file = "../../images/guru/" . $nama_file;

                // check extension
                $file = explode(".", $nama_file);
                $extension = array_pop($file);

                // jika foto tidak diubah
                if (empty($_FILES['foto']['name'])) {
                    // perintah query untuk mengubah data pada tabel gurus
                    $query = mysqli_query($mysqli, "INSERT INTO tb_guru(nip,password,nama_lengkap,tempat_lahir,tanggal_lahir,jenis_kelamin,status_perkawinan,alamat_lengkap,no_telepon,agama,honor_session,foto)
                                      VALUES('$nip','$password','$nama_lengkap','$tempat_lahir','$tanggal_lahir','$jenis_kelamin','$status_perkawinan','$alamat_lengkap','$no_telepon','$agama','$honor_session','$nama_file')")
                    or die('Ada kesalahan pada query insert : ' . mysqli_error($mysqli));

                    // cek query
                    if ($query) {
                        // jika berhasil tampilkan pesan berhasil update data
                        header("location: ../../main.php?module=guru&alert=1");
                    }
                } else {
                    // Cek apakah tipe file yang diupload sesuai dengan allowed_extensions
                    if (in_array($extension, $allowed_extensions)) {
                        // Jika tipe file yang diupload sesuai dengan allowed_extensions, lakukan :
                        if ($ukuran_file <= 1000000) { // Cek apakah ukuran file yang diupload kurang dari sama dengan 1MB
                            // Jika ukuran file kurang dari sama dengan 1MB, lakukan :
                            // Proses upload
                            if (move_uploaded_file($tmp_file, $path_file)) { // Cek apakah gambar berhasil diupload atau tidak
                                // Jika gambar berhasil diupload, Lakukan :
                                // perintah query untuk mengubah data pada tabel gurus
                                $query = mysqli_query($mysqli, "INSERT INTO tb_guru(nip,password,nama_lengkap,tempat_lahir,tanggal_lahir,jenis_kelamin,status_perkawinan,alamat_lengkap,no_telepon,agama,honor_session,foto)
                                      VALUES('$nip','$password','$nama_lengkap','$tempat_lahir','$tanggal_lahir','$jenis_kelamin','$status_perkawinan','$alamat_lengkap','$no_telepon','$agama','$honor_session','$nama_file')")
                                or die('Ada kesalahan pada query insert : ' . mysqli_error($mysqli));

                                // cek query
                                if ($query) {
                                    // jika berhasil tampilkan pesan berhasil update data
                                    header("location: ../../main.php?module=guru&alert=1");
                                }
                            } else {
                                // Jika gambar gagal diupload, tampilkan pesan gagal upload
                                header("location: ../../main.php?module=guru&alert=2");
                            }
                        } else {
                            // Jika ukuran file lebih dari 1MB, tampilkan pesan gagal upload
                            header("location: ../../main.php?module=guru&alert=3");
                        }
                    } else {
                        // Jika tipe file yang diupload bukan jpg, jpeg, png, tampilkan pesan gagal upload
                        header("location: ../../main.php?module=guru&alert=4");
                    }
                }
            }
        }
    } // update
    elseif ($_GET['act'] == 'update') {
        if (isset($_POST['simpan'])) {
            if (isset($_POST['nip'])) {
                // ambil data hasil submit dari form
                $nip = mysqli_real_escape_string($mysqli, trim($_POST['nip']));
                $nama_lengkap = mysqli_real_escape_string($mysqli, trim($_POST['nama_lengkap']));
                $tempat_lahir = mysqli_real_escape_string($mysqli, trim($_POST['tempat_lahir']));

                $tanggal = mysqli_real_escape_string($mysqli, trim($_POST['tanggal_lahir']));
                $tgl = explode('-', $tanggal);
                $tanggal_lahir = $tgl[2] . "-" . $tgl[1] . "-" . $tgl[0];

                $jenis_kelamin = mysqli_real_escape_string($mysqli, trim($_POST['jenis_kelamin']));
                $status_perkawinan = mysqli_real_escape_string($mysqli, trim($_POST['status_perkawinan']));
                $alamat_lengkap = mysqli_real_escape_string($mysqli, trim($_POST['alamat_lengkap']));
                $no_telepon = mysqli_real_escape_string($mysqli, trim($_POST['no_telepon']));
                $agama = mysqli_real_escape_string($mysqli, trim($_POST['agama']));
                $honor_session       = str_replace('.', '', trim($_POST['honor_session']));

                $nama_file = $_FILES['foto']['name'];
                $ukuran_file = $_FILES['foto']['size'];
                $tipe_file = $_FILES['foto']['type'];
                $tmp_file = $_FILES['foto']['tmp_name'];

                // tentuka extension yang diperbolehkan
                $allowed_extensions = array('jpg', 'jpeg', 'png');

                // Set path folder tempat menyimpan gambarnya
                $path_file = "../../images/guru/" . $nama_file;

                // check extension
                $file = explode(".", $nama_file);
                $extension = array_pop($file);

                // jika foto tidak diubah
                if (empty($_FILES['foto']['name'])) {
                    // perintah query untuk mengubah data pada tabel gurus
                    $query = mysqli_query($mysqli, "UPDATE tb_guru SET nama_lengkap         = '$nama_lengkap',
                    							                        tempat_lahir        = '$tempat_lahir',
                                                                        tanggal_lahir       = '$tanggal_lahir',
                                                                        jenis_kelamin       = '$jenis_kelamin',
                                                                        status_perkawinan   = '$status_perkawinan',
                                                                        alamat_lengkap      = '$alamat_lengkap',
                                                                        no_telepon          = '$no_telepon',
                                                                        agama               = '$agama',
                                                                        honor_session       = '$honor_session'
                                                                  WHERE nip = '$nip'")
                    or die('Ada kesalahan pada query update : ' . mysqli_error($mysqli));

                    // cek query
                    if ($query) {
                        // jika berhasil tampilkan pesan berhasil update data
                        header("location: ../../main.php?module=guru&alert=2");
                    }
                } // jika foto diubah
                else {
                    // Cek apakah tipe file yang diupload sesuai dengan allowed_extensions
                    if (in_array($extension, $allowed_extensions)) {
                        // Jika tipe file yang diupload sesuai dengan allowed_extensions, lakukan :
                        if ($ukuran_file <= 1000000) { // Cek apakah ukuran file yang diupload kurang dari sama dengan 1MB
                            // Jika ukuran file kurang dari sama dengan 1MB, lakukan :
                            // Proses upload
                            if (move_uploaded_file($tmp_file, $path_file)) { // Cek apakah gambar berhasil diupload atau tidak
                                // Jika gambar berhasil diupload, Lakukan : 
                                // perintah query untuk mengubah data pada tabel gurus
                                $query = mysqli_query($mysqli, "UPDATE tb_guru SET nama_lengkap         = '$nama_lengkap',
                    							                        tempat_lahir        = '$tempat_lahir',
                                                                        tanggal_lahir       = '$tanggal_lahir',
                                                                        jenis_kelamin       = '$jenis_kelamin',
                                                                        status_perkawinan   = '$status_perkawinan',
                                                                        alamat_lengkap      = '$alamat_lengkap',
                                                                        no_telepon          = '$no_telepon',
                                                                        agama               = '$agama',
                                                                        honor_session       = '$honor_session',
                                                                        foto                = '$nama_file'
                                                                  WHERE nip = '$nip'")
                                or die('Ada kesalahan pada query update : ' . mysqli_error($mysqli));

                                // cek query
                                if ($query) {
                                    // jika berhasil tampilkan pesan berhasil update data
                                    header("location: ../../main.php?module=guru&alert=2");
                                }
                            } else {
                                // Jika gambar gagal diupload, tampilkan pesan gagal upload
                                header("location: ../../main.php?module=guru&alert=4");
                            }
                        } else {
                            // Jika ukuran file lebih dari 1MB, tampilkan pesan gagal upload
                            header("location: ../../main.php?module=guru&alert=5");
                        }
                    } else {
                        // Jika tipe file yang diupload bukan jpg, jpeg, png, tampilkan pesan gagal upload
                        header("location: ../../main.php?module=guru&alert=6");
                    }
                }
            }
        }
    } elseif ($_GET['act'] == 'delete') {
        if (isset($_GET['id'])) {
            $nip = $_GET['id'];

            /// fungsi query untuk menampilkan data dari tabel guru
            $result = mysqli_query($mysqli, "SELECT * FROM tb_guru WHERE nip='$nip'")
            or die('Ada kesalahan pada query tampil data guru: ' . mysqli_error($mysqli));

            $data = mysqli_fetch_assoc($result);
            $foto = $data['foto'];
            // hapus file foto dari folder foto
            $hapus_file = unlink("../../images/guru/$foto");

            // perintah query untuk menghapus data pada tabel guru
            $query = mysqli_query($mysqli, "DELETE FROM tb_guru WHERE nip='$nip'")
            or die('Ada kesalahan pada query delete : ' . mysqli_error($mysqli));

            // cek hasil query
            if ($query) {
                // jika berhasil tampilkan pesan berhasil delete data
                header("location: ../../main.php?module=guru&alert=3");
            }

        }
    }
}
?>