<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        <i class="fa fa-graduation-cap icon-title"></i> Data Delivery To Customer Performance

        <a class="btn btn-primary btn-social pull-right" href="?module=form_lap_dcp&form=add" title="Tambah Data"
           data-toggle="tooltip">
            <i class="fa fa-plus"></i> Tambah
        </a>
        &nbsp;
        <a class="btn btn-primary btn-social pull-right" href="?module=cetak_lap_dcp&form=print" title="Cetak Data"
           data-toggle="tooltip">
            <i class="glyphicon glyphicon-print"></i> Cetak Data
        </a>
    </h1>

</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">

            <?php
            // fungsi untuk menampilkan pesan
            // jika alert = "" (kosong)
            // tampilkan pesan "" (kosong)
            if (empty($_GET['alert'])) {
                echo "";
            }
            // jika alert = 1
            // tampilkan pesan Sukses "Customer baru berhasil disimpan"
            elseif ($_GET['alert'] == 1) {
                echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Sukses!</h4>
              Data Delivery To Customer Performance baru berhasil di import.
            </div>";
            }
            // jika alert = 2
            // tampilkan pesan Sukses "Customer berhasil diubah"
            elseif ($_GET['alert'] == 2) {
                echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Sukses!</h4>
              Data Delivery To Customer Performance diubah.
            </div>";
            }
            // jika alert = 3
            // tampilkan pesan Sukses "Customer berhasil dihapus"
            elseif ($_GET['alert'] == 3) {
                echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Sukses!</h4>
			  Data Delivery To Customer Performance berhasil dihapus.
            </div>";
            }
            ?>

            <div class="box box-primary">
                <div class="box-body">
                    <!-- tampilan tabel sekolah -->
                    <table id="dataTables1" class="table table-bordered table-striped table-hover">
                        <!-- tampilan tabel header -->
                        <thead>
                        <tr>
                            <th class="center">No.</th>
                            <th class="center">Tanggal</th>
                            <th class="center">Nama Store</th>
                            <th class="center">Order Date</th>
                            <th class="center">Order No</th>
                            <th class="center">Type</th>
                            <th class="center">Posting Date</th>
                            <th class="center">Close date</th>
                            <th class="center">Promised Date</th>
                            <th class="center">Delivery Day</th>
                            <th class="center">Delivery Day Category</th>
                            <th class="center">Delivery Status</th>

                            <th></th>
                        </tr>
                        </thead>
                        <!-- tampilan tabel body -->
                        <tbody>
                        <?php
                        $no = 1;
                        // fungsi query untuk menampilkan data dari tabel customer
                        $query = mysqli_query($mysqli, "SELECT * FROM tb_lap_dcp ORDER BY id_store DESC")
                        or die('Ada kesalahan pada query tampil Data Customer: ' . mysqli_error($mysqli));

                        // tampilkan data
                        while ($data = mysqli_fetch_assoc($query)) {
                            // menampilkan isi tabel dari database ke tabel di aplikasi
                            echo "<tr>
                      <td width='40' class='center'>$no</td>
                      <td width='40'>$data[tanggal]</td>
                      <td width='40'>$data[nama_store]</td>
                      <td width='40'>$data[order_date]</td>
                      <td width='40'>$data[order_no]</td>
                      <td width='40'>$data[type]</td>
                      <td width='40'>$data[posting_date]</td>
                      <td width='40'>$data[close_date]</td>
                      <td width='40'>$data[promised_date]</td>
                      <td width='40'>$data[dlv_day]</td>
                      <td width='40'>$data[dlv_day_cat]</td>
                      <td width='40'>$data[dlv_status]</td>
                      <td class='center' width='80'>
                        <div>
                          ";
                            ?>
                            <a data-toggle="tooltip" data-placement="top" title="Hapus" class="btn btn-danger btn-sm"
                               href="modules/lap-dcp/proses.php?act=delete&id=<?php echo $data['id_lap_dcp']; ?>"
                               onclick="return confirm('Anda yakin ingin menghapus data <?php echo $data['id_lap_dcp']; ?> ?');">
                                <i style="color:#fff" class="glyphicon glyphicon-trash"></i>
                            </a>
                            <?php
                            echo "    </div>
                      </td>
                    </tr>";
                            $no++;
                        }
                        ?>
                        </tbody>
                    </table>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div><!--/.col -->
    </div>   <!-- /.row -->
</section><!-- /.content