<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        <i class="fa fa-home icon-title"></i> Beranda
    </h1>
    <ol class="breadcrumb">
        <li><a href="?module=home"><i class="fa fa-home"></i> Beranda</a></li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-lg-12 col-xs-12">
            <div class="alert alert-info alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <p style="font-size:15px">
                    <i class="icon fa fa-user"></i> Selamat datang
                    <strong><?php echo $_SESSION['nama_lengkap']; ?></strong> di Aplikasi E-Report Mitra 10.
                  
                </p>
            </div>
        </div>
    </div>

    <!-- Small boxes (Stat box) -->
    <div class="row">
        <?php
        if ($_SESSION['hak_akses'] == 'Admin') { ?>
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div style="background-color:#00c0ef;color:#fff" class="small-box">
                    <div class="inner">
                        <?php
                        // fungsi query untuk menampilkan data dari tabel barang
                        $query = mysqli_query($mysqli, "SELECT COUNT(nip) as jumlah FROM tb_guru")
                        or die('Ada kesalahan pada query tampil Data Guru: ' . mysqli_error($mysqli));

                        // tampilkan data
                        $data = mysqli_fetch_assoc($query);
                        ?>
                        <h3><?php echo $data['jumlah']; ?></h3>
                        <p>Data Deputy Manager</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-group"></i>
                    </div>
                    <a href="?module=form_guru&form=add" class="small-box-footer" title="Tambah Data"
                       data-toggle="tooltip"><i class="fa fa-plus"></i></a>
                </div>
            </div><!-- ./col -->

            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div style="background-color:#00a65a;color:#fff" class="small-box">
                    <div class="inner">
                        <?php
                        // fungsi query untuk menampilkan data dari tabel barang masuk
                        $query = mysqli_query($mysqli, "SELECT COUNT(nip) as jumlah FROM tb_staff")
                        or die('Ada kesalahan pada query tampil Data Staff: ' . mysqli_error($mysqli));

                        // tampilkan data
                        $data = mysqli_fetch_assoc($query);
                        ?>
                        <h3><?php echo $data['jumlah']; ?></h3>
                        <p>Data Store Manager</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-group"></i>
                    </div>
                    <a href="?module=form_staff&form=add" class="small-box-footer" title="Tambah Data"
                       data-toggle="tooltip"><i class="fa fa-plus"></i></a>
                </div>
            </div><!-- ./col -->

            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div style="background-color:#f39c12;color:#fff" class="small-box">
                    <div class="inner">
                        <?php
                        // fungsi query untuk menampilkan data dari tabel koordinator
                        $query = mysqli_query($mysqli, "SELECT COUNT(id_koordinator) as jumlah FROM tb_koordinator")
                        or die('Ada kesalahan pada query tampil Data Koordinator: ' . mysqli_error($mysqli));

                        // tampilkan data
                        $data = mysqli_fetch_assoc($query);
                        ?>
                        <h3><?php echo $data['jumlah']; ?></h3>
                        <p>Data Regional Manager</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-group"></i>
                    </div>
                    <a href="?module=form_koordinator&form=add" class="small-box-footer" title="Tambah Data"
                       data-toggle="tooltip"><i class="fa fa-plus"></i></a>
                </div>
            </div><!-- ./col -->

            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div style="background-color:#dd4b39;color:#fff" class="small-box">
                    <div class="inner">
                        <?php
                        // fungsi query untuk menampilkan data dari tabel user
                        $query = mysqli_query($mysqli, "SELECT COUNT(id_sekolah) as jumlah FROM tb_sekolah")
                        or die('Ada kesalahan pada query tampil Data Sekolah: ' . mysqli_error($mysqli));

                        // tampilkan data
                        $data = mysqli_fetch_assoc($query);
                        ?>
                        <h3><?php echo $data['jumlah']; ?></h3>
                        <p>Data Store</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-graduation-cap"></i>
                    </div>
                    <a href="?module=form_sekolah&form=add" class="small-box-footer" title="Tambah Data"
                       data-toggle="tooltip"><i class="fa fa-plus"></i></a>
                </div>
            </div><!-- ./col -->
            <?php

        }
        ?>

    </div><!-- /.row -->

    <br>
</section><!-- /.content -->