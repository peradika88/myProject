<script type="text/javascript">


    function tampil_gapok(input) {
        var num = input.value;

        $.post("modules/gaji-staff/gaji.php", {
            dataidgaji: num,
        }, function (response) {
            $('#gaji_pokok').html(response)

            document.getElementById('uang_hadir').focus();
        });
    }

    function hitung_total_gaji() {
        bil1 = document.formGajiStaff.gaji_pokok.value;
        bil2 = document.formGajiStaff.total_uang_hadir.value;
        bil3 = document.formGajiStaff.honor_tambahan.value;

        if (bil1 == "") {
            var hasil = 0;
        } else if (bil2 == "") {
            var hasil = 0;
        } else if (bil3 == "") {
            var hasil = 0;
        } else {
            var hasil = eval(convertToAngka(bil1)) + eval(convertToAngka(bil2)) + eval(convertToAngka(bil3));
        }

        document.formGajiStaff.total_gaji.value = convertToRupiah(hasil);
    }

    function hitung_total_hadir() {
        bil1 = document.formGajiStaff.uang_hadir.value;
        bil2 = document.formGajiStaff.jml_hadir.value;

        if (bil2 == "") {
            var hasil = 0;
        } else if (bil2 == "") {
            var hasil = 0;
        } else {
            var hasil = eval(convertToAngka(bil1)) * eval(bil2);
        }

        document.formGajiStaff.total_uang_hadir.value = convertToRupiah(hasil);
    }

    function hitung_total_gajiditerima() {
        bil1 = document.formGajiStaff.pot_kasbon.value;
        bil2 = document.formGajiStaff.pot_dplk.value;
        bil3 = document.formGajiStaff.pot_lain.value;
        bil4 = document.formGajiStaff.pot_bpjs.value;
        bil5 = document.formGajiStaff.pot_pph21.value;
        bil6 = document.formGajiStaff.total_gaji.value;


        if (bil1 == "") {
            var hasil = 0;
        } else if (bil2 == "") {
            var hasil = 0;
        } else if (bil3 == "") {
            var hasil = 0;
        } else if (bil4 == "") {
            var hasil = 0;
        } else if (bil5 == "") {
            var hasil = 0;
        } else {
            var hasil = eval(convertToAngka(bil6)) - (eval(convertToAngka(bil1)) + eval(convertToAngka(bil2)) + eval(convertToAngka(bil3)) + eval(convertToAngka(bil4)) + eval(convertToAngka(bil5)));
        }

        document.formGajiStaff.total_gaji_diterima.value = convertToRupiah(hasil);
    }
</script>
<?php
// fungsi untuk pengecekan tampilan form
// jika form add data yang dipilih
if ($_GET['form'] == 'add') {
    ?>
    <!-- tampilan form add data -->
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-edit icon-title"></i> Input Data Gaji Staff
        </h1>
        <ol class="breadcrumb">
            <li><a href="?module=home"><i class="fa fa-home"></i> Beranda </a></li>
            <li><a href="?module=gaji_staff"> Gaji Staff </a></li>
            <li class="active"> Tambah</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <!-- form start -->
                    <form role="form" class="form-horizontal" action="../admin/modules/gaji-staff/proses.php?act=insert"
                          method="POST" name="formGajiStaff">
                        <div class="box-body">
                            <?php
                            // fungsi untuk membuat id transaksi
                            $query_id = mysqli_query($mysqli, "SELECT RIGHT(id_gaji_staff,7) as kode FROM tb_gaji_staff
                                                ORDER BY id_gaji_staff DESC LIMIT 1")
                            or die('Ada kesalahan pada query tampil id_gaji_staff : ' . mysqli_error($mysqli));

                            $count = mysqli_num_rows($query_id);

                            if ($count <> 0) {
                                // mengambil data id_gaji_staff
                                $data_id = mysqli_fetch_assoc($query_id);
                                $kode = $data_id['kode'] + 1;
                            } else {
                                $kode = 1;
                            }

                            // buat id_gaji_staff
                            $bulan = (date("m"));
                            $tahun = date("Y");
                            $buat_id = str_pad($kode, 7, "0", STR_PAD_LEFT);
                            $id_gaji_staff = "GJ-$tahun-$buat_id";
                            ?>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">ID Transaksi</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="id_gaji_staff"
                                           value="<?php echo $id_gaji_staff; ?>" readonly required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Tanggal</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control date-picker" data-date-format="dd-mm-yyyy"
                                           name="tanggal" autocomplete="off" value="<?php echo date("d-m-Y"); ?>"
                                           readonly required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Gaji Bulan</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="bulan"
                                           value="<?php echo bulan($bulan); ?>" readonly required>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Staff</label>
                                <div class="col-sm-5">
                                    <select class="chosen-select" name="nip" data-placeholder="-- Pilih Staff --"
                                            onchange="tampil_gapok(this)" autocomplete="off" required>
                                        <option value=""></option>
                                        <?php
                                        $query_staff = mysqli_query($mysqli, "SELECT nip, nama_lengkap FROM tb_staff ORDER BY nip ASC")
                                        or die('Ada kesalahan pada query tampil staff: ' . mysqli_error($mysqli));
                                        while ($data_staff = mysqli_fetch_assoc($query_staff)) {
                                            echo "<option value=\"$data_staff[nip]\"> $data_staff[nip] | $data_staff[nama_lengkap] </option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <hr>
                            <span id='gaji_pokok'>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Gaji Pokok</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="gaji_pokok" name="gaji_pokok"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_hadir(this)&hitung_total_gaji(this)&hitung_total_gajiditerima(this)"
                                               required>
                                    </div>
                                </div>
                            </div>
                            </span>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Uang Hadir</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="uang_hadir" name="uang_hadir"
                                               required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Jumlah Hadir</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="jml_hadir" name="jml_hadir"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_hadir(this)&hitung_total_gaji(this)&hitung_total_gajiditerima(this)"
                                               required>
                                        <span class="input-group-addon">Hari</span>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Total Uang Hadir</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="total_uang_hadir"
                                               name="total_uang_hadir" readonly
                                               required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Honor Tambahan</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="honor_tambahan"
                                               name="honor_tambahan"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_hadir(this)&hitung_total_gaji(this)&hitung_total_gajiditerima(this)"
                                               required>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Total Gaji</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="total_gaji" name="total_gaji"
                                               readonly
                                               required>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan Kasbon</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_kasbon" name="pot_kasbon"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_hadir(this)&hitung_total_gaji(this)&hitung_total_gajiditerima(this)"
                                               required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan DPLK</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_dplk" name="pot_dplk"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_hadir(this)&hitung_total_gaji(this)&hitung_total_gajiditerima(this)"
                                               required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan Lain-lain</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_lain" name="pot_lain"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_hadir(this)&hitung_total_gaji(this)&hitung_total_gajiditerima(this)"
                                               required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan BPJS</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_bpjs" name="pot_bpjs"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_hadir(this)&hitung_total_gaji(this)&hitung_total_gajiditerima(this)"
                                               required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan PPH21</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_pph21" name="pot_pph21"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_hadir(this)&hitung_total_gaji(this)&hitung_total_gajiditerima(this)"
                                               required>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Total Gaji Diterima</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="total_gaji_diterima"
                                               name="total_gaji_diterima" readonly
                                               required>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="box-footer">
                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <input type="submit" class="btn btn-primary btn-submit" name="simpan"
                                               value="Simpan">
                                        <a href="?module=gaji_staff" class="btn btn-default btn-reset">Batal</a>
                                    </div>
                                </div>
                            </div><!-- /.box footer -->
                    </form>
                </div><!-- /.box -->
            </div><!--/.col -->
        </div>   <!-- /.row -->
    </section><!-- /.content -->
    <?php
} // jika form edit data yang dipilih
elseif ($_GET['form'] == 'edit') {
    if (isset($_GET['id'])) {

        // fungsi query untuk menampilkan data dari tabel gaji_staff
        $query = mysqli_query($mysqli, "SELECT * FROM tb_gaji_staff as a INNER JOIN tb_staff as b
                                            ON a.nip=b.nip WHERE id_gaji_staff='$_GET[id]' ORDER BY a.id_gaji_staff DESC")
        or die('Ada kesalahan pada query tampil data gaji_staff : ' . mysqli_error($mysqli));
        $data = mysqli_fetch_assoc($query);

        $t_gaji_staff = $data['tanggal'];
        $tgl = explode('-', $t_gaji_staff);
        $tanggal = $tgl[2] . "-" . $tgl[1] . "-" . $tgl[0];

    }
    ?>
    <!-- tampilkan form edit data -->
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-edit icon-title"></i> Ubah Data Guru
        </h1>
        <ol class="breadcrumb">
            <li><a href="?module=beranda"><i class="fa fa-home"></i> Beranda</a></li>
            <li><a href="?module=guru"> Guru </a></li>
            <li class="active"> Ubah</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <!-- form start -->
                    <form role="form" class="form-horizontal" action="../admin/modules/gaji-staff/proses.php?act=update"
                          method="POST" name="formGajiStaff">
                        <div class="box-body">

                            <div class="form-group">
                                <label class="col-sm-2 control-label">ID Transaksi</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="id_gaji_staff"
                                           value="<?php echo $data['id_gaji_staff']; ?>" readonly required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Tanggal</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control date-picker" data-date-format="dd-mm-yyyy"
                                           name="tanggal" autocomplete="off" value="<?php echo $tanggal; ?>"
                                           readonly required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Gaji Bulan</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="bulan"
                                           value="<?php echo $data['bulan']; ?>" readonly required>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Staff</label>
                                <div class="col-sm-5">
                                    <select class="chosen-select" name="nip" data-placeholder="-- Pilih Staff --"
                                            autocomplete="off" required>
                                        <option value="<?php echo $data['nip']; ?>"><?php echo $data['nip']; ?>
                                            | <?php echo $data['nama_lengkap']; ?></option>
                                        <?php
                                        $query_staff = mysqli_query($mysqli, "SELECT nip, nama_lengkap FROM tb_staff ORDER BY nip ASC")
                                        or die('Ada kesalahan pada query tampil staff: ' . mysqli_error($mysqli));
                                        while ($data_staff = mysqli_fetch_assoc($query_staff)) {
                                            echo "<option value=\"$data_staff[nip]\"> $data_staff[nip] | $data_staff[nama_lengkap] </option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Gaji Pokok</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="gaji_pokok" name="gaji_pokok"
                                               value="<?php echo $data['gaji_pokok']; ?>"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gaji(this)" required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Uang Hadir</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="uang_hadir" name="uang_hadir"
                                               value="<?php echo $data['uang_hadir']; ?>" required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Jumlah Hadir</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="jml_hadir" name="jml_hadir"
                                               value="<?php echo $data['jml_hadir']; ?>"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_hadir(this)" required>
                                        <span class="input-group-addon">Hari</span>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Total Uang Hadir</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="total_uang_hadir"
                                               name="total_uang_hadir" value="<?php echo $data['total_uang_hadir']; ?>"
                                               readonly
                                               required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Honor Tambahan</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="honor_tambahan"
                                               name="honor_tambahan" value="<?php echo $data['honor_tambahan']; ?>"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gaji(this)" required>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Total Gaji</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="total_gaji" name="total_gaji"
                                               value="<?php echo $data['total_gaji']; ?>" readonly
                                               required>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan Kasbon</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_kasbon" name="pot_kasbon"
                                               value="<?php echo $data['pot_kasbon']; ?>"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gajiditerima(this)" required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan DPLK</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_dplk" name="pot_dplk"
                                               value="<?php echo $data['pot_dplk']; ?>"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gajiditerima(this)" required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan Lain-lain</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_lain" name="pot_lain"
                                               value="<?php echo $data['pot_lain']; ?>"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gajiditerima(this)" required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan BPJS</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_bpjs" name="pot_bpjs"
                                               value="<?php echo $data['pot_bpjs']; ?>"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gajiditerima(this)" required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan PPH21</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_pph21" name="pot_pph21"
                                               value="<?php echo $data['pot_pph21']; ?>"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gajiditerima(this)" required>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Total Gaji Diterima</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="total_gaji_diterima"
                                               name="total_gaji_diterima"
                                               value="<?php echo $data['total_gaji_diterima']; ?>" readonly
                                               required>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="box-footer">
                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <input type="submit" class="btn btn-primary btn-submit" name="simpan"
                                               value="Simpan">
                                        <a href="?module=gaji_staff" class="btn btn-default btn-reset">Batal</a>
                                    </div>
                                </div>
                            </div><!-- /.box footer -->
                    </form>
                </div><!-- /.box -->
            </div><!--/.col -->
        </div>   <!-- /.row -->
    </section><!-- /.content -->
    <?php
}
?>