<?php
session_start();

// Panggil koneksi database.php untuk koneksi database
require_once "../../../config/database.php";

if (isset($_POST['dataidgaji'])) {
    $nip = $_POST['dataidgaji'];

    // fungsi query untuk menampilkan data dari tabel barang
    $query = mysqli_query($mysqli, "SELECT gaji_pokok  FROM tb_staff WHERE nip='$nip'")
    or die('Ada kesalahan pada query tampil data barang: ' . mysqli_error($mysqli));

    // tampilkan data
    $data = mysqli_fetch_assoc($query);

    $gaji_pokok = $data['gaji_pokok'];

    if ($gaji_pokok != '') {
        echo "<div class='form-group'>
                <label class='col-sm-2 control-label'>Gaji Pokok</label>
                <div class='col-sm-5'>
                  <div class='input-group'>
                  <span class='input-group-addon'>Rp.</span>
                    <input type='text' class='form-control uang' id='gaji_pokok' name='gaji_pokok' value='$gaji_pokok' readonly>
                  </div>
                </div>
              </div>";
    } else {
        echo "<div class='form-group'>
                <label class='col-sm-2 control-label'>Gaji Pokok</label>
                <div class='col-sm-5'>
                  <div class='input-group'>
                  <span class='input-group-addon'>Rp.</span>
                    <input type='text' class='form-control' id='gaji_pokok' name='gaji_pokok' value='Gaji Pokok tidak ditemukan' readonly>
                  </div>
                </div>
              </div>";
    }
}
?> 