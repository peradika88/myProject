<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        <i class="fa fa-graduation-cap icon-title"></i> Data Item ABCD Class

        <a class="btn btn-primary btn-social pull-right" href="?module=form_lap_abcd&form=add" title="Tambah Data"
           data-toggle="tooltip">
            <i class="fa fa-plus"></i> Tambah
        </a>
        &nbsp;
        <a class="btn btn-primary btn-social pull-right" href="?module=cetak_lap_abcd&form=print" title="Cetak Data"
           data-toggle="tooltip">
            <i class="glyphicon glyphicon-print"></i> Cetak Data
        </a>
    </h1>

</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">

            <?php
            // fungsi untuk menampilkan pesan
            // jika alert = "" (kosong)
            // tampilkan pesan "" (kosong)
            if (empty($_GET['alert'])) {
                echo "";
            }
            // jika alert = 1
            // tampilkan pesan Sukses "Customer baru berhasil disimpan"
            elseif ($_GET['alert'] == 1) {
                echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Sukses!</h4>
              Data baru berhasil di import.
            </div>";
            }
            // jika alert = 2
            // tampilkan pesan Sukses "Customer berhasil diubah"
            elseif ($_GET['alert'] == 2) {
                echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Sukses!</h4>
              Data diubah.
            </div>";
            }
            // jika alert = 3
            // tampilkan pesan Sukses "Customer berhasil dihapus"
            elseif ($_GET['alert'] == 3) {
                echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Sukses!</h4>
			  Data berhasil dihapus.
            </div>";
            }
            ?>

            <div class="box box-primary">
                <div class="box-body">
                    <!-- tampilan tabel sekolah -->
                    <table id="dataTables1" class="table table-bordered table-striped table-hover">
                        <!-- tampilan tabel header -->
                        <thead>
                        <tr>
                            <th class="center">No.</th>
                            <th class="center">Tanggal</th>
                            <th class="center">Nama Store</th>
                            <th class="center">Item No</th>
                            <th class="center">Description</th>
                            <th class="center">Category Code</th>
                            <th class="center">Category</th> 

                            <th></th>
                        </tr>
                        </thead>
                        <!-- tampilan tabel body -->
                        <tbody>
                        <?php
                        $no = 1;
                        // fungsi query untuk menampilkan data dari tabel customer
                        $query = mysqli_query($mysqli, "SELECT * FROM tb_lap_abcd ORDER BY id_abcd DESC")
                        or die('Ada kesalahan pada query tampil Data Customer: ' . mysqli_error($mysqli));

                        // tampilkan data
                        while ($data = mysqli_fetch_assoc($query)) {
                            // menampilkan isi tabel dari database ke tabel di aplikasi
                            echo "<tr>
                      <td width='40' class='center'>$no</td>
                      <td width='40'>$data[tanggal]</td>
                      <td width='40'>$data[nama_store]</td>
                      <td width='40'>$data[item_no]</td>
                      <td width='40'>$data[description]</td>
                      <td width='40'>$data[cat_kode]</td>
                      <td width='40'>$data[category]</td>
                      <td class='center' width='80'>
                        <div>
                          ";
                            ?>
                            <a data-toggle="tooltip" data-placement="top" title="Hapus" class="btn btn-danger btn-sm"
                               href="modules/lap-dcp/proses.php?act=delete&id=<?php echo $data['id_lap_abcd']; ?>"
                               onclick="return confirm('Anda yakin ingin menghapus data <?php echo $data['id_lap_abcd']; ?> ?');">
                                <i style="color:#fff" class="glyphicon glyphicon-trash"></i>
                            </a>
                            <?php
                            echo "    </div>
                      </td>
                    </tr>";
                            $no++;
                        }
                        ?>
                        </tbody>
                    </table>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div><!--/.col -->
    </div>   <!-- /.row -->
</section><!-- /.content