<?php
// fungsi untuk pengecekan tampilan form
// jika form add data yang dipilih
if ($_GET['form'] == 'add') { ?>

 <section class="content-header">
        <h1>
            <i class="fa fa-edit icon-title"></i> Import Data Item ABCD Class
        </h1>
        <ol class="breadcrumb">
            <li><a href="?module=home"><i class="fa fa-home"></i> Beranda </a></li>
            <li><a href="?module=lap_abcd"> Data ABCD Class </a></li>
            <li class="active"> Tambah</li>
        </ol>
 </section>
 
 


<!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <!-- form start -->
					 <div class="box-body">

						<?php 

						?>

                        <a href="./../import-abcd.xls"><button id="alert2" type="button" class="btn btn-warning"><i class="fa fa-download" aria-hidden="true"></i> Download Template Xls</button></a>
                        <h5><p align="left">Pastikan file yang di upload menggunakan file XLS (Excel 2003)<br>
                        download template Xls diatas</b></h5>
                        <br><br>

						<form method="post" enctype="multipart/form-data" action="../admin/modules/lap-abcd/proses.php?act=insert"">
							Pilih File: 
							<input name="filepegawai" type="file" required="required"> <br>
							<input name="upload" type="submit" value="Import" class="btn btn-primary">
						</form>
						

 </div><!-- /.box body -->

                        <div class="box-footer">
                            
                        </div><!-- /.box footer -->
                    </form>
                </div><!-- /.box -->
            </div><!--/.col -->
        </div>   <!-- /.row -->
    </section><!-- /.content -->

   <?php
}
?>

