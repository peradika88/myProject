<?php
session_start();

// Panggil koneksi database.php untuk koneksi database
require_once "../../../config/database.php";

// menghubungkan dengan library excel reader
include "../../../admin/excel_reader2.php";
?>

    
<?php
if ($_GET['act'] == 'insert') {
	if (isset($_POST['simpan'])) {


						// upload file xls
						$target = basename($_FILES['filepegawai']['name']) ;
						move_uploaded_file($_FILES['filepegawai']['tmp_name'], $target);

						// beri permisi agar file xls dapat di baca
						chmod($_FILES['filepegawai']['name'],0777);

						// mengambil isi file xls
						$data = new Spreadsheet_Excel_Reader($_FILES['filepegawai']['name'],false);
						// menghitung jumlah baris data yang ada
						$jumlah_baris = $data->rowcount($sheet_index=0);

						// jumlah default data yang berhasil di import
						$berhasil = 0;
						for ($i=2; $i<=$jumlah_baris; $i++)
							{

								// menangkap data dan memasukkan ke variabel sesuai dengan kolumnya masing-masing
								$tanggal  	  = $data->val($i, 1);
								$id_store     = $data->val($i, 2);
								$nama_store   = $data->val($i, 3);
								$order_date   = $data->val($i, 4);
								$order_no  	  = $data->val($i, 5);
								$type         = $data->val($i, 6);
								$posting_date = $data->val($i, 7);
								$close_date   = $data->val($i, 8);
								$promised_date  = $data->val($i, 9);
								$dlv_day      = $data->val($i, 10);
								$dlv_day_cat  = $data->val($i, 11);
								$dlv_status   = $data->val($i, 12);

								if($tanggal != "" && $id_store != "" && $nama_store != "" && $order_date != "" && $order_no != "" && $type != "" && $posting_date != ""
								&& $close_date != "" && $promised_date != "" && $dlv_day != "" && $dlv_day_cat != "" && $dlv_status != "" )
								{
									// input data ke database (table data_pegawai)
									mysqli_query($mysqli,"INSERT into tb_lap_dcp values('','$tanggal','$id_store','$nama_store','$order_date','$order_no','$type','$posting_date'
									,'$close_date','$promised_date','$dlv_day','$dlv_day_cat','$dlv_status')");
									$berhasil++;
								}
							}

							// hapus kembali file .xls yang di upload tadi
							unlink($_FILES['filepegawai']['name']);

							// alihkan halaman ke list
							header("location: ../../main.php?module=lap_dcp&alert=1");
					
				}
			}   elseif ($_GET['act'] == 'delete') {
				if (isset($_GET['id'])) {
					$id_lap_dcp = $_GET['id'];
		
					// perintah query untuk menghapus data pada tabel sekolah
					$query = mysqli_query($mysqli, "DELETE FROM tb_lap_dcp WHERE id_lap_dcp='$id_lap_dcp'")
					or die('Ada kesalahan pada query delete : ' . mysqli_error($mysqli));
		
					// cek hasil query
					if ($query) {
						// jika berhasil tampilkan pesan berhasil delete data
						header("location: ../../main.php?module=lap_dcp&alert=3");
					}


				}
			}
				
				?>