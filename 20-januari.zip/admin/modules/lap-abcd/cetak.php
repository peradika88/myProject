<?php
session_start();
ob_start();

// Panggil koneksi database.php untuk koneksi database
require_once "../../../config/database.php";
// panggil fungsi untuk format tanggal
include "../../../config/fungsi_tanggal.php";
include "../../../config/fungsi_rupiah.php";

$hari_ini = date("d-m-Y");

// ambil data hasil submit dari form
$tgl1 = $_GET['tgl_awal'];
$explode = explode('-', $tgl1);
$tgl_awal = $explode[2] . "-" . $explode[1] . "-" . $explode[0];

$tgl2 = $_GET['tgl_akhir'];
$explode = explode('-', $tgl2);
$tgl_akhir = $explode[2] . "-" . $explode[1] . "-" . $explode[0];

if (isset($_GET['tgl_awal'])) {
    $no = 1;
    // fungsi query untuk menampilkan data dari tabel Absensi Guru

    $query = mysqli_query($mysqli, "SELECT * FROM tb_lap_dcp ORDER BY id_store DESC")
    or die('Ada kesalahan pada query tampil Data Absensi Guru: ' . mysqli_error($mysqli));

    $count = mysqli_num_rows($query);
}
?>
    <html xmlns="http://www.w3.org/1999/xhtml"> <!-- Bagian halaman HTML yang akan konvert -->
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
        <title>LAPORAN DATA DELIVERY TO CUSTOMER PERFORMANCE</title>
        <link rel="stylesheet" type="text/css" href="../../../assets/css/laporan.css"/>
    </head>
    <body>
    <div id="title">
        LAPORAN DATA DATA DELIVERY TO CUSTOMER PERFORMANCE
    </div>
    <?php
    if ($tgl_awal == $tgl_akhir) { ?>
        <div id="title-tanggal">
            Tanggal <?php echo tgl_eng_to_ind($tgl1); ?>
        </div>
        <?php
    } else { ?>
        <div id="title-tanggal">
            Tanggal <?php echo tgl_eng_to_ind($tgl1); ?> s.d. <?php echo tgl_eng_to_ind($tgl2); ?>
        </div>
        <?php
    }
    ?>

    <hr>
    <br>
    <div id="isi">
        <table width="100%" border="0.3" cellpadding="0" cellspacing="0">
            <thead style="background:#e8ecee">
            <tr class="tr-title">
                <th height="20" align="center" valign="middle">No.</th>
                <th height="20" align="center" valign="middle">Tanggal</th>
                <th height="20" align="center" valign="middle">Nama Store</th>
                <th height="20" align="center" valign="middle">Order Date</th>
                <th height="20" align="center" valign="middle">Order No</th>
                <th height="20" align="center" valign="middle">Type</th>
                <th height="20" align="center" valign="middle">Posting Date</th>
                <th height="20" align="center" valign="middle">Close Date</th>
                <th height="20" align="center" valign="middle">Promised Date</th>
                <th height="20" align="center" valign="middle">Delivery Day</th>
                <th height="20" align="center" valign="middle">Delivery Day Category</th>
                <th height="20" align="center" valign="middle">Delivery Status</th>
            </tr>
            </thead>
            <tbody>
            <?php
            // jika data ada
            if ($count == 0) {
                echo "  <tr>
                      <td width='40' height='13' align='center' valign='middle'></td>
                      <td width='80' height='13' align='center' valign='middle'></td>
                      <td width='100' height='13' align='center' valign='middle'></td>
                      <td style='padding-left:5px;' width='150' height='13' valign='middle'></td>
                      <td width='100' height='13' align='center' valign='middle'></td>
                      <td style='padding-left:5px;' width='150' height='13' valign='middle'></td>
                      <td width='100' align='center' height='13' valign='middle'></td>
                      <td width='150' height='13' align='center' valign='middle'></td> 
                      <td width='40' height='13' align='center' valign='middle'></td>
                      <td width='40' height='13' align='center' valign='middle'></td>
                      <td width='40' height='13' align='center' valign='middle'></td>
                      <td width='40' height='13' align='center' valign='middle'></td>                 
                </tr>";
            } // jika data tidak ada
            else {
                // tampilkan data
                while ($data = mysqli_fetch_assoc($query)) {
                    $tanggal = $data['tanggal'];
                    $exp = explode('-', $tanggal);
                    $tanggal_jadwal = tgl_eng_to_ind($exp[2] . "-" . $exp[1] . "-" . $exp[0]);

                    // menampilkan isi tabel dari database ke tabel di aplikasi
                    echo "  <tr>
                      <td width='40' height='13' align='center' valign='middle'>$no</td>
                      <td width='100' height='13' align='center' valign='middle'>$tanggal_jadwal</td>
                      <td width='100' height='13' align='center' valign='middle'>$data[nama_store]</td>
                      <td width='100' height='13' align='center' valign='middle'>$data[order_date]</td>
                      <td width='100' height='13' align='center' valign='middle'>$data[order_no]</td>
                      <td width='100' height='13' align='center' valign='middle'>$data[type]</td>
                      <td width='80' height='13' align='center' valign='middle'>$data[posting_date]</td>
                      <td width='80' height='13' align='center' valign='middle'>$data[close_date]</td>    
                      <td width='80' height='13' align='center' valign='middle'>$data[promised_date]</td>
                      <td width='50' height='13' align='center' valign='middle'>$data[dlv_day]</td>
                      <td width='50' height='13' align='center' valign='middle'>$data[dlv_day_cat]</td>
                      <td width='80' height='13' align='center' valign='middle'>$data[dlv_status]</td>                       
                    </tr>";
                    $no++;
                }
            }
            ?>
            </tbody>
        </table>

        <div id="footer-tanggal">
            Tanggerang, <?php echo tgl_eng_to_ind("$hari_ini"); ?>
        </div>
        <div id="footer-jabatan">
            General Manager
        </div>

        <div id="footer-nama">
            <?php echo $_SESSION['nama_lengkap']; ?>
        </div>
    </div>
    </body>
    </html><!-- Akhir halaman HTML yang akan di konvert -->
<?php
$filename = "LAPORAN DATA DCP.pdf"; //ubah untuk menentukan nama file pdf yang dihasilkan nantinya
//==========================================================================================================
$content = ob_get_clean();
$content = '<page style="font-family: freeserif">' . ($content) . '</page>';
// panggil library html2pdf
require_once('../../../assets/plugins/html2pdf_v4.03/html2pdf.class.php');
try {
    $html2pdf = new HTML2PDF('L', 'F4', 'en', false, 'ISO-8859-15', array(10, 10, 10, 10));
    $html2pdf->setDefaultFont('Arial');
    $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
    $html2pdf->Output($filename);
} catch (HTML2PDF_exception $e) {
    echo $e;
}
?>