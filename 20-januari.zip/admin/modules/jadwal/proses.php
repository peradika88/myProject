<?php

session_start();

// Panggil koneksi database.php untuk koneksi database
require_once "../../../config/database.php";

// fungsi untuk pengecekan status login admin
// jika admin belum login, alihkan ke halaman login dan tampilkan pesan = 1
if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
    echo "<meta http-equiv='refresh' content='0; url=login.php?alert=1'>";
} // jika admin sudah login, maka jalankan perintah untuk insert dan update
else {
    // insert data
    if ($_GET['act'] == 'insert') {
        if (isset($_POST['simpan'])) {
            // ambil data hasil submit dari form
            $id_jadwal_guru = mysqli_real_escape_string($mysqli, trim($_POST['id_jadwal_guru']));
            $nip = mysqli_real_escape_string($mysqli, trim($_POST['nip']));
			$author = mysqli_real_escape_string($mysqli, trim($_POST['author']));
			$descr = mysqli_real_escape_string($mysqli, trim($_POST['descr']));
			
            $nama_file = $nip . "_" . $_FILES['jadwal']['name'];
            $ukuran_file = $_FILES['jadwal']['size'];
            $tipe_file = $_FILES['jadwal']['type'];
            $tmp_file = $_FILES['jadwal']['tmp_name'];

            // tentukan extension yang diperbolehkan
            $allowed_extensions = array('pdf', 'PDF');

            // Set path folder tempat menyimpan gambarnya
            $path_file = "../../../jadwal/" . $nama_file;

            // check extension
            $file = explode(".", $nama_file);
            $extension = array_pop($file);

            // Cek apakah tipe file yang diupload sesuai dengan allowed_extensions
            if (in_array($extension, $allowed_extensions)) {
                // Jika tipe file yang diupload sesuai dengan allowed_extensions, lakukan :
                if ($ukuran_file <= 1000000) { // Cek apakah ukuran file yang diupload kurang dari sama dengan 1MB
                    // Jika ukuran file kurang dari sama dengan 1MB, lakukan :
                    // Proses upload
                    if (move_uploaded_file($tmp_file, $path_file)) { // Cek apakah file berhasil diupload atau tidak
                        // Jika file berhasil diupload, Lakukan :
                        // perintah query untuk menyimpan data ke tabel jadwal
                        $query = mysqli_query($mysqli, "INSERT INTO tb_jadwal_guru(id_jadwal_guru,nip,author,descr,jadwal)
                                            VALUES('$id_jadwal_guru','$nip','$author','$descr','$nama_file')")
                        or die('Ada kesalahan pada query insert : ' . mysqli_error($mysqli));

                        // cek query
                        if ($query) {
                            // jika berhasil tampilkan pesan berhasil simpan data
                            header("location: ../../../admin/main.php?module=jadwal_guru&alert=1");
                        }
                    } else {
                        // Jika file gagal diupload, tampilkan pesan gagal upload
                        header("location: ../../../admin/main.php?module=jadwal_guru&alert=4");
                    }
                } else {
                    // Jika ukuran file lebih dari 1 Mb, tampilkan pesan gagal upload
                    header("location: ../../../admin/main.php?module=jadwal_guru&alert=5");
                }
            } else {
                // Jika tipe file yang diupload bukan PDF, tampilkan pesan gagal upload
                header("location: ../../../admin/main.php?module=jadwal_guru&alert=6");
            }

        }
    } // update
    elseif ($_GET['act'] == 'update') {
        if (isset($_POST['simpan'])) {
            if (isset($_POST['id_jadwal_guru'])) {
                // ambil data hasil submit dari form
                $id_jadwal_guru = mysqli_real_escape_string($mysqli, trim($_POST['id_jadwal_guru']));
                $nip = mysqli_real_escape_string($mysqli, trim($_POST['nip']));
				$desc = mysqli_real_escape_string($mysqli, trim($_POST['desc']));
				
                $nama_file = $nip . "_" . $_FILES['jadwal']['name'];
                $ukuran_file = $_FILES['jadwal']['size'];
                $tipe_file = $_FILES['jadwal']['type'];
                $tmp_file = $_FILES['jadwal']['tmp_name'];

                // tentukan extension yang diperbolehkan
                $allowed_extensions = array('pdf', 'PDF');

                // Set path folder tempat menyimpan gambarnya
                $path_file = "../../../jadwal/" . $nama_file;

                // check extension
                $file = explode(".", $nama_file);
                $extension = array_pop($file);


                // jika jadwal tidak diubah
                if (empty($_POST['check_jadwal'])) {
                    // perintah query untuk mengubah data pada tabel surat_keputusan
                    $query = mysqli_query($mysqli, "UPDATE tb_jadwal_guru SET  nip         = '$nip'
                                                                          WHERE id_jadwal_guru  = '$id_jadwal_guru'")
                    or die('Ada kesalahan pada query update : ' . mysqli_error($mysqli));

                    // cek query
                    if ($query) {
                        // jika berhasil tampilkan pesan berhasil update data
                        header("location: ../../main.php?module=jadwal_guru&alert=2");
                    }
                } // jika jadwal diubah
                else {
                    // Cek apakah tipe file yang diupload sesuai dengan allowed_extensions
                    if (in_array($extension, $allowed_extensions)) {
                        // Jika tipe file yang diupload sesuai dengan allowed_extensions, lakukan :
                        if ($ukuran_file <= 1000000) { // Cek apakah ukuran file yang diupload kurang dari sama dengan 1MB
                            // Jika ukuran file kurang dari sama dengan 1MB, lakukan :
                            // Proses upload
                            if (move_uploaded_file($tmp_file, $path_file)) { // Cek apakah file berhasil diupload atau tidak
                                // Jika file berhasil diupload, Lakukan :
                                // perintah query untuk mengubah data pada tabel jadwal guru
                                $query = mysqli_query($mysqli, "UPDATE tb_jadwal_guru SET  nip      = '$nip',
                                                                                                jadwal    = '$nama_file'
                                                                          WHERE id_jadwal_guru  = '$id_jadwal_guru'")
                                or die('Ada kesalahan pada query update : ' . mysqli_error($mysqli));

                                // cek query
                                if ($query) {
                                    // jika berhasil tampilkan pesan berhasil update data
                                    header("location: ../../main.php?module=jadwal_guru&alert=2");
                                }
                            } else {
                                // Jika file gagal diupload, tampilkan pesan gagal upload
                                header("location: ../../main.php?module=jadwal_guru&alert=4");
                            }
                        } else {
                            // Jika ukuran file lebih dari 1 Mb, tampilkan pesan gagal upload
                            header("location: ../../main.php?module=jadwal_guru&alert=5");
                        }
                    } else {
                        // Jika tipe file yang diupload bukan PDF, tampilkan pesan gagal upload
                        header("location: ../../main.php?module=jadwal_guru&alert=6");
                    }
                }
            }
        }
    } elseif ($_GET['act'] == 'delete') {
        if (isset($_GET['id'])) {
            $id_jadwal_guru = $_GET['id'];

            // perintah query untuk menampilkan data edoc berdasaran id_sk
            $query = mysqli_query($mysqli, "SELECT jadwal FROM tb_jadwal_guru WHERE id_jadwal_guru='$id_jadwal_guru'")
            or die('Ada kesalahan pada query tampil jadwal: ' . mysqli_error($mysqli));
            $data = mysqli_fetch_assoc($query);
            $jadwal = $data['jadwal'];

            // hapus file edoc dari folder dokumen
            $hapus_file = unlink("../../../jadwal/$jadwal");

            // cek hapus file
            if ($hapus_file) {
                // perintah query untuk menghapus data pada tabel surat_keputusan
                $query = mysqli_query($mysqli, "DELETE FROM tb_jadwal_guru WHERE id_jadwal_guru='$id_jadwal_guru'")
                or die('Ada kesalahan pada query delete : ' . mysqli_error($mysqli));

                // cek hasil query
                if ($query) {
                    // jika berhasil tampilkan pesan berhasil delete data
                    header("location: ../../main.php?module=jadwal_guru&alert=3");
                }
            }
        }
    }
}
?>