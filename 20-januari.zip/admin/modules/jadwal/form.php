<?php
// fungsi untuk pengecekan tampilan form
// jika form add data yang dipilih
if ($_GET['form'] == 'add') {
    ?>
    <!-- tampilan form add data -->
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-edit icon-title"></i> Input Data File
        </h1>
        <ol class="breadcrumb">
            <li><a href="?module=home"><i class="fa fa-home"></i> Beranda </a></li>
            <li><a href="?module=jadwal_guru"> File </a></li>
            <li class="active"> Tambah</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <!-- form start -->
                    <form role="form" class="form-horizontal"
                          action="../admin/modules/jadwal/proses.php?act=insert"
                          method="POST" enctype="multipart/form-data">
                        <div class="box-body">
                            <?php
                            // fungsi untuk membuat id jadwal
                            $query_id = mysqli_query($mysqli, "SELECT RIGHT(id_jadwal_guru,4) as kode FROM tb_jadwal_guru
                                                ORDER BY id_jadwal_guru DESC LIMIT 1")
                            or die('Ada kesalahan pada query tampil id_jadwal_guru : ' . mysqli_error($mysqli));

                            $count = mysqli_num_rows($query_id);

                            if ($count <> 0) {
                                // mengambil data id_jadwal_guru
                                $data_id = mysqli_fetch_assoc($query_id);
                                $kode = $data_id['kode'] + 1;
                            } else {
                                $kode = 1;
                            }

                            // buat id_jadwal_guru
                            $buat_id = str_pad($kode, 4, "0", STR_PAD_LEFT);
                            $id_jadwal_guru = "F$buat_id";
                            ?>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">ID File</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="id_jadwal_guru" autocomplete="off"
                                           value="<?php echo $id_jadwal_guru; ?>" readonly required>
                                </div>
                            </div>

							<div class="form-group">
                                <label class="col-sm-2 control-label">Author</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="author" autocomplete="off"
                                           value="<?php echo $_SESSION['nama_lengkap']; ?>" readonly required>
                                </div>
                            </div> 

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Nama File</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="nip" autocomplete="off" required>
                                </div>
                            </div>
							
							 <div class="form-group">
                                <label class="col-sm-2 control-label">Deskripsi</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="descr" autocomplete="off" required>
                                </div>
                            </div>
							
                            <div class="form-group">
                                <label class="col-sm-2 control-label">File</label>
                                <div class="col-sm-5">
                                    <input type="file" id="file" name="jadwal">
                                    <p class="help-block">
                                        <small>Catatan :</small>
                                        <br>
                                        <small>- Pastikan file yang diupload bertipe *.PDF</small>
                                        <br>
                                        <small>- Ukuran file pdf max 1 MB</small>
                                    </p>
                                </div>
                            </div>

                            <hr>

                            <div class="box-footer">
                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <input type="submit" class="btn btn-primary btn-submit" name="simpan"
                                               value="Simpan">
                                        <a href="?module=jadwal_guru" class="btn btn-default btn-reset">Batal</a>
                                    </div>
                                </div>
                            </div><!-- /.box footer -->
                    </form>
                </div><!-- /.box -->
            </div><!--/.col -->
        </div>   <!-- /.row -->
    </section><!-- /.content -->
    <?php
} // jika form edit data yang dipilih
elseif ($_GET['form'] == 'edit') {
    if (isset($_GET['id'])) {

        // fungsi query untuk menampilkan data dari tabel jadwal_guru
        $query = mysqli_query($mysqli, "SELECT t1.id_jadwal_guru, t2.nip, t2.nama_lengkap, t1.jadwal FROM tb_jadwal_guru t1, tb_guru t2 WHERE t2.nip=t1.nip ORDER BY t1.id_jadwal_guru DESC")
        or die('Ada kesalahan pada query tampil Data Jadwal Guru: ' . mysqli_error($mysqli));
        $data = mysqli_fetch_assoc($query);


    }
    ?>
    <!-- tampilkan form edit data -->
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-edit icon-title"></i> Ubah Data Jadwal Guru
        </h1>
        <ol class="breadcrumb">
            <li><a href="?module=beranda"><i class="fa fa-home"></i> Beranda</a></li>
            <li><a href="?module=jadwal_guru"> Jadwal Guru </a></li>
            <li class="active"> Ubah</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <!-- form start -->
                    <form role="form" class="form-horizontal" action="../admin/modules/jadwal/proses.php?act=update"
                          method="POST" enctype="multipart/form-data">
                        <div class="box-body">

                            <div class="form-group">
                                <label class="col-sm-2 control-label">ID Jadwal</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="id_jadwal_guru" autocomplete="off"
                                           value="<?php echo $data['id_jadwal_guru']; ?>" readonly required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Nama Guru</label>
                                <div class="col-sm-5">
                                    <select class="chosen-select" name="nip" data-placeholder="-- Pilih Guru --"
                                            autocomplete="off" required>
                                        <option value="<?php echo $data['nip']; ?>"><?php echo $data['nip']; ?>
                                            | <?php echo $data['nama_lengkap']; ?></option>
                                        <?php
                                        $query_guru = mysqli_query($mysqli, "SELECT nip, nama_lengkap FROM tb_guru ORDER BY nip ASC")
                                        or die('Ada kesalahan pada query tampil guru: ' . mysqli_error($mysqli));
                                        while ($data_guru = mysqli_fetch_assoc($query_guru)) {
                                            echo "<option value=\"$data_guru[nip]\"> $data_guru[nip] | $data_guru[nama_lengkap] </option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">File Jadwal</label>
                                <div class="col-sm-5">
                                    <input type="file" name="jadwal">
                                    <br>
                                    <label><input type="checkbox" name="check_jadwal" value="Y"> Ceklis jika jadwal guru diubah</label>
                                    <p class="help-block">
                                        <small>Catatan :</small>
                                        <br>
                                        <small>- Pastikan file yang diupload bertipe *.PDF</small>
                                        <br>
                                        <small>- Ukuran file pdf max 1 MB</small>
                                    </p>
                                </div>
                            </div>

                            <hr>

                            <div class="box-footer">
                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <input type="submit" class="btn btn-primary btn-submit" name="simpan"
                                               value="Simpan">
                                        <a href="?module=jadwal_guru" class="btn btn-default btn-reset">Batal</a>
                                    </div>
                                </div>
                            </div><!-- /.box footer -->
                    </form>
                </div><!-- /.box -->
            </div><!--/.col -->
        </div>   <!-- /.row -->
    </section><!-- /.content -->
    <?php
}
?>