<?php
session_start();

// Panggil koneksi database.php untuk koneksi database
require_once "../../../config/database.php";

// fungsi untuk pengecekan status login user 
// jika user belum login, alihkan ke halaman login dan tampilkan pesan = 1
if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
    echo "<meta http-equiv='refresh' content='0; url=login.php?alert=1'>";
} // jika user sudah login, maka jalankan perintah untuk insert, update, dan delete
else {
    if ($_GET['act'] == 'insert') {
        if (isset($_POST['simpan'])) {
            // ambil data hasil submit dari form
            $id_sekolah = mysqli_real_escape_string($mysqli, trim($_POST['id_sekolah']));
            $kepala_sekolah = mysqli_real_escape_string($mysqli, trim($_POST['kepala_sekolah']));
            $nama_sekolah = mysqli_real_escape_string($mysqli, trim($_POST['nama_sekolah']));
            $alamat_lengkap = mysqli_real_escape_string($mysqli, trim($_POST['alamat_lengkap']));
            $no_telepon = mysqli_real_escape_string($mysqli, trim($_POST['no_telepon']));
            $email = mysqli_real_escape_string($mysqli, trim($_POST['email']));


            // perintah query untuk menyimpan data ke tabel sekolah
            $query = mysqli_query($mysqli, "INSERT INTO tb_sekolah(id_sekolah,kepala_sekolah,nama_sekolah,alamat_lengkap,no_telepon,email) 
                                            VALUES('$id_sekolah','$kepala_sekolah','$nama_sekolah','$alamat_lengkap','$no_telepon','$email')")
            or die('Ada kesalahan pada query insert : ' . mysqli_error($mysqli));

            // cek query
            if ($query) {
                // jika berhasil tampilkan pesan berhasil simpan data
                header("location: ../../main.php?module=sekolah&alert=1");
            }
        }
    } elseif ($_GET['act'] == 'update') {
        if (isset($_POST['simpan'])) {
            if (isset($_POST['id_sekolah'])) {
                // ambil data hasil submit dari form
                $id_sekolah = mysqli_real_escape_string($mysqli, trim($_POST['id_sekolah']));
                $kepala_sekolah = mysqli_real_escape_string($mysqli, trim($_POST['kepala_sekolah']));
                $nama_sekolah = mysqli_real_escape_string($mysqli, trim($_POST['nama_sekolah']));
                $alamat_lengkap = mysqli_real_escape_string($mysqli, trim($_POST['alamat_lengkap']));
                $no_telepon = mysqli_real_escape_string($mysqli, trim($_POST['no_telepon']));
                $email = mysqli_real_escape_string($mysqli, trim($_POST['email']));

                // perintah query untuk mengubah data pada tabel sekolah
                $query = mysqli_query($mysqli, "UPDATE tb_sekolah SET kepala_sekolah   = '$kepala_sekolah',
                                                                     nama_sekolah   = '$nama_sekolah',
                                                                     alamat_lengkap = '$alamat_lengkap',
                                                                     no_telepon     = '$no_telepon',
                                                                     email          = '$email'
                                                               WHERE id_sekolah     = '$id_sekolah'")
                or die('Ada kesalahan pada query update : ' . mysqli_error($mysqli));

                // cek query
                if ($query) {
                    // jika berhasil tampilkan pesan berhasil update data
                    header("location: ../../main.php?module=sekolah&alert=2");
                }
            }
        }
    } elseif ($_GET['act'] == 'delete') {
        if (isset($_GET['id'])) {
            $id_sekolah = $_GET['id'];

            // perintah query untuk menghapus data pada tabel sekolah
            $query = mysqli_query($mysqli, "DELETE FROM tb_sekolah WHERE id_sekolah='$id_sekolah'")
            or die('Ada kesalahan pada query delete : ' . mysqli_error($mysqli));

            // cek hasil query
            if ($query) {
                // jika berhasil tampilkan pesan berhasil delete data
                header("location: ../../main.php?module=sekolah&alert=3");
            }
        }
    }
}
?>