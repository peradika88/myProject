<script type="text/javascript">

    function tampil_jumlah(input){
        var num = input.value;

        $.post("modules/gaji-guru/gaji.php", {
            dataidgaji: num,
        }, function(response) {
            $('#jml_sesion').html(response)
        });
    }

    function tampil_honor(input){
        var num = input.value;

        $.post("modules/gaji-guru/gaji2.php", {
            dataidgaji: num,
        }, function(response) {
            $('#honor_sesion').html(response)
            document.getElementById('honor_rapat').focus();
        });
    }

    function hitung_total_gaji() {
        bil1 = document.formGajiGuru.total_honor_sesion.value;
        bil2 = document.formGajiGuru.honor_rapat.value;
        bil3 = document.formGajiGuru.subsidi_dplk.value;
        bil4 = document.formGajiGuru.tambahan_transport.value;

        if (bil1 == "") {
            var hasil = "0";
        } else if (bil2 == "") {
            var hasil = "0";
        } else if (bil3 == "") {
            var hasil = "0";
        } else if (bil4 == "") {
            var hasil = "0";
        } else {
            var hasil = eval(convertToAngka(bil1)) + eval(convertToAngka(bil2)) + eval(convertToAngka(bil3)) + eval(convertToAngka(bil4));
        }

        document.formGajiGuru.total_gaji.value = convertToRupiah(hasil);
    }

    function hitung_total_sesion() {
        bil1 = document.formGajiGuru.honor_sesion.value;
        bil2 = document.formGajiGuru.jml_sesion.value;

        if (bil1 == "") {
            var hasil = "0";
        } else if (bil2 == "") {
            var hasil = "0";
        } else {
            var hasil = eval(convertToAngka(bil1)) * eval(bil2);
        }

        document.formGajiGuru.total_honor_sesion.value = convertToRupiah(hasil);
    }

    function hitung_total_gajiditerima() {
        bil1 = document.formGajiGuru.pot_kasbon.value;
        bil2 = document.formGajiGuru.pot_dplk.value;
        bil3 = document.formGajiGuru.pot_lain.value;
        bil4 = document.formGajiGuru.pot_pph21.value;
        bil5 = document.formGajiGuru.total_gaji.value;


        if (bil1 == "") {
            var hasil = "0";
        } else if (bil2 == "") {
            var hasil = "0";
        } else if (bil3 == "") {
            var hasil = "0";
        } else if (bil4 == "") {
            var hasil = "0";
        } else if (bil5 == "") {
            var hasil = "0";
        } else {
            var hasil = eval(convertToAngka(bil5)) - (eval(convertToAngka(bil1)) + eval(convertToAngka(bil2)) + eval(convertToAngka(bil3)) + eval(convertToAngka(bil4)));
        }

        document.formGajiGuru.total_gaji_diterima.value = convertToRupiah(hasil);
    }
</script>
<?php
// fungsi untuk pengecekan tampilan form
// jika form add data yang dipilih
if ($_GET['form'] == 'add') {
    ?>
    <!-- tampilan form add data -->
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-edit icon-title"></i> Input Data Gaji Guru
        </h1>
        <ol class="breadcrumb">
            <li><a href="?module=home"><i class="fa fa-home"></i> Beranda </a></li>
            <li><a href="?module=gaji_guru"> Gaji Guru </a></li>
            <li class="active"> Tambah</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <!-- form start -->
                    <form role="form" class="form-horizontal" action="../admin/modules/gaji-guru/proses.php?act=insert"
                          method="POST" name="formGajiGuru">
                        <div class="box-body">
                            <?php
                            // fungsi untuk membuat id transaksi
                            $query_id = mysqli_query($mysqli, "SELECT RIGHT(id_gaji_guru,7) as kode FROM tb_gaji_guru
                                                ORDER BY id_gaji_guru DESC LIMIT 1")
                            or die('Ada kesalahan pada query tampil id_gaji_guru : ' . mysqli_error($mysqli));

                            $count = mysqli_num_rows($query_id);

                            if ($count <> 0) {
                                // mengambil data id_gaji_guru
                                $data_id = mysqli_fetch_assoc($query_id);
                                $kode = $data_id['kode'] + 1;
                            } else {
                                $kode = 1;
                            }

                            // buat id_gaji_guru
                            $bulan = (date("m"));
                            $tahun = date("Y");
                            $buat_id = str_pad($kode, 7, "0", STR_PAD_LEFT);
                            $id_gaji_guru = "GJ-$tahun-$buat_id";
                            ?>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">ID Transaksi</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="id_gaji_guru"
                                           value="<?php echo $id_gaji_guru; ?>" readonly required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Tanggal</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control date-picker" data-date-format="dd-mm-yyyy"
                                           name="tanggal" autocomplete="off" value="<?php echo date("d-m-Y"); ?>"
                                           readonly required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Gaji Bulan</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="bulan"
                                           value="<?php echo bulan($bulan); ?>" readonly required>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Guru</label>
                                <div class="col-sm-5">
                                    <select class="chosen-select" name="nip" data-placeholder="-- Pilih Guru --"
                                            onchange="tampil_jumlah(this)&tampil_honor(this)&hitung_total_sesion(this)" autocomplete="off" required>
                                        <option value=""></option>
                                        <?php
                                        $query_guru = mysqli_query($mysqli, "SELECT nip, nama_lengkap FROM tb_guru ORDER BY nip ASC")
                                        or die('Ada kesalahan pada query tampil guru: ' . mysqli_error($mysqli));
                                        while ($data_guru = mysqli_fetch_assoc($query_guru)) {
                                            echo "<option value=\"$data_guru[nip]\"> $data_guru[nip] | $data_guru[nama_lengkap] </option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <hr>

                            <span id='jml_sesion'>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Jumlah Session</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="jml_sesion" name="jml_sesion"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gaji(this)&hitung_total_sesion(this)&hitung_total_gajiditerima(this)"
                                               required>
                                        <span class="input-group-addon">Session</span>
                                    </div>
                                </div>
                            </div>
                            </span>
                            <span id='honor_sesion'>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Honor Sesion</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="honor_sesion"
                                               name="honor_sesion"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gaji(this)&hitung_total_sesion(this)&hitung_total_gajiditerima(this)"
                                               required>
                                    </div>
                                </div>
                            </div>
                            </span>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Total Honor Sesion</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="total_honor_sesion"
                                               name="total_honor_sesion" readonly
                                               required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Honor Rapat</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="honor_rapat"
                                               name="honor_rapat"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gaji(this)&hitung_total_sesion(this)&hitung_total_gajiditerima(this)"
                                               required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Subsidi DPLK</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="subsidi_dplk"
                                               name="subsidi_dplk"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gaji(this)&hitung_total_sesion(this)&hitung_total_gajiditerima(this)"
                                               required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Tambahan Transport</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="tambahan_transport"
                                               name="tambahan_transport"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gaji(this)&hitung_total_sesion(this)&hitung_total_gajiditerima(this)"
                                               required>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Total Gaji</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="total_gaji" name="total_gaji"
                                               readonly
                                               required>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan Kasbon</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_kasbon" name="pot_kasbon"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gaji(this)&hitung_total_sesion(this)&hitung_total_gajiditerima(this)"
                                               required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan Lain-lain</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_lain" name="pot_lain"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gaji(this)&hitung_total_sesion(this)&hitung_total_gajiditerima(this)"
                                               required>
                                    </div>
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan DPLK</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_dplk" name="pot_dplk"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gaji(this)&hitung_total_sesion(this)&hitung_total_gajiditerima(this)"
                                               required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan PPH21</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_pph21" name="pot_pph21"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gaji(this)&hitung_total_sesion(this)&hitung_total_gajiditerima(this)"
                                               required>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Total Gaji Diterima</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="total_gaji_diterima"
                                               name="total_gaji_diterima" readonly
                                               required>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="box-footer">
                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <input type="submit" class="btn btn-primary btn-submit" name="simpan"
                                               value="Simpan">
                                        <a href="?module=gaji_guru" class="btn btn-default btn-reset">Batal</a>
                                    </div>
                                </div>
                            </div><!-- /.box footer -->
                    </form>
                </div><!-- /.box -->
            </div><!--/.col -->
        </div>   <!-- /.row -->
    </section><!-- /.content -->
    <?php
} // jika form edit data yang dipilih
elseif ($_GET['form'] == 'edit') {
    if (isset($_GET['id'])) {

        // fungsi query untuk menampilkan data dari tabel gaji_guru
        $query = mysqli_query($mysqli, "SELECT * FROM tb_gaji_guru as a INNER JOIN tb_guru as b
                                            ON a.nip=b.nip WHERE id_gaji_guru='$_GET[id]' ORDER BY a.id_gaji_guru DESC")
        or die('Ada kesalahan pada query tampil data gaji_guru : ' . mysqli_error($mysqli));
        $data = mysqli_fetch_assoc($query);

        $t_gaji_guru = $data['tanggal'];
        $tgl = explode('-', $t_gaji_guru);
        $tanggal = $tgl[2] . "-" . $tgl[1] . "-" . $tgl[0];

    }
    ?>
    <!-- tampilkan form edit data -->
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-edit icon-title"></i> Ubah Data Guru
        </h1>
        <ol class="breadcrumb">
            <li><a href="?module=beranda"><i class="fa fa-home"></i> Beranda</a></li>
            <li><a href="?module=guru"> Guru </a></li>
            <li class="active"> Ubah</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <!-- form start -->
                    <form role="form" class="form-horizontal" action="../admin/modules/gaji-guru/proses.php?act=update"
                          method="POST" name="formGajiGuru">
                        <div class="box-body">

                            <div class="form-group">
                                <label class="col-sm-2 control-label">ID Transaksi</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="id_gaji_guru"
                                           value="<?php echo $data['id_gaji_guru']; ?>" readonly required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Tanggal</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control date-picker" data-date-format="dd-mm-yyyy"
                                           name="tanggal" autocomplete="off" value="<?php echo $tanggal; ?>"
                                           readonly required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Gaji Bulan</label>
                                <div class="col-sm-5">
                                    <input type="text" class="form-control" name="bulan"
                                           value="<?php echo $data['bulan']; ?>" readonly required>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Guru</label>
                                <div class="col-sm-5">
                                    <select class="chosen-select" name="nip" data-placeholder="-- Pilih Guru --"
                                            autocomplete="off" required>
                                        <option value="<?php echo $data['nip']; ?>"><?php echo $data['nip']; ?>
                                            | <?php echo $data['nama_lengkap']; ?></option>
                                        <?php
                                        $query_guru = mysqli_query($mysqli, "SELECT nip, nama_lengkap FROM tb_guru ORDER BY nip ASC")
                                        or die('Ada kesalahan pada query tampil guru: ' . mysqli_error($mysqli));
                                        while ($data_guru = mysqli_fetch_assoc($query_guru)) {
                                            echo "<option value=\"$data_guru[nip]\"> $data_guru[nip] | $data_guru[nama_lengkap] </option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Jumlah Sesion</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="jml_sesion" name="jml_sesion"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_sesion(this)"
                                               value="<?php echo $data['jml_sesion']; ?>" disabled required>
                                        <span class="input-group-addon">Session</span>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Honor Sesion</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="honor_sesion"
                                               name="honor_sesion"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gaji(this)"
                                               value="<?php echo $data['honor_sesion']; ?>" required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Total Honor Sesion</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="total_honor_sesion"
                                               name="total_honor_sesion" readonly
                                               value="<?php echo $data['total_honor_sesion']; ?>" required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Honor Rapat</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="honor_rapat"
                                               name="honor_rapat"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gaji(this)"
                                               value="<?php echo $data['honor_rapat']; ?>" required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Subsidi DPLK</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="subsidi_dplk"
                                               name="subsidi_dplk"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gaji(this)"
                                               value="<?php echo $data['subsidi_dplk']; ?>" required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Tambahan Transport</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="tambahan_transport"
                                               name="tambahan_transport"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gaji(this)"
                                               value="<?php echo $data['tambahan_transport']; ?>" required>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Total Gaji</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="total_gaji" name="total_gaji"
                                               readonly value="<?php echo $data['total_gaji']; ?>" required>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan Kasbon</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_kasbon" name="pot_kasbon"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gajiditerima(this)"
                                               value="<?php echo $data['pot_kasbon']; ?>" required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan Lain-lain</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_lain" name="pot_lain"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gajiditerima(this)"
                                               value="<?php echo $data['pot_lain']; ?>" required>
                                    </div>
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan DPLK</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_dplk" name="pot_dplk"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gajiditerima(this)"
                                               value="<?php echo $data['pot_dplk']; ?>" required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Potongan PPH21</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="pot_pph21" name="pot_pph21"
                                               autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"
                                               onkeyup="hitung_total_gajiditerima(this)"
                                               value="<?php echo $data['pot_pph21']; ?>" required>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <label class="col-sm-2 control-label">Total Gaji Diterima</label>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-addon">Rp.</span>
                                        <input type="text" class="form-control uang" id="total_gaji_diterima"
                                               name="total_gaji_diterima" readonly
                                               value="<?php echo $data['total_gaji_diterima']; ?>" required>
                                    </div>
                                </div>
                            </div>


                            <hr>

                            <div class="box-footer">
                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <input type="submit" class="btn btn-primary btn-submit" name="simpan"
                                               value="Simpan">
                                        <a href="?module=gaji_guru" class="btn btn-default btn-reset">Batal</a>
                                    </div>
                                </div>
                            </div><!-- /.box footer -->
                    </form>
                </div><!-- /.box -->
            </div><!--/.col -->
        </div>   <!-- /.row -->
    </section><!-- /.content -->
    <?php
}
?>