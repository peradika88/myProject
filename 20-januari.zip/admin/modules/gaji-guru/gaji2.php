<?php
session_start();

// Panggil koneksi database.php untuk koneksi database
require_once "../../../config/database.php";

if (isset($_POST['dataidgaji'])) {
    $nip = $_POST['dataidgaji'];

    // fungsi query untuk menampilkan data dari tabel barang
    $query = mysqli_query($mysqli, "SELECT honor_session FROM tb_guru WHERE nip='$nip'")
    or die('Ada kesalahan pada query tampil data gaji: ' . mysqli_error($mysqli));

    // tampilkan data
    $data = mysqli_fetch_assoc($query);

    $honor_sesion = $data['honor_session'];


    if ($honor_sesion != '') {
        echo "<div class='form-group'>
                <label class='col-sm-2 control-label'>Honor Sesion</label>
                <div class='col-sm-5'>
                  <div class='input-group'>
                  <span class=\"input-group-addon\">Rp.</span>
                    <input type='text' class='form-control uang' id='honor_sesion' name='honor_sesion' value='$honor_sesion' readonly>
                  </div>
                </div>
              </div>";
    } else {
        echo "<div class='form-group'>
                <label class='col-sm-2 control-label'>Honor Sesion</label>
                <div class='col-sm-5'>
                  <div class='input-group'>
                  <span class=\"input-group-addon\">Rp.</span>
                    <input type='text' class='form-control uang' id='honor_sesion' name='honor_sesion' value='Honor Session tidak ditemukan' readonly>
                  </div>
                </div>
              </div>";
    }
}
?> 