<?php
session_start();

// Panggil koneksi database.php untuk koneksi database
require_once "../../../config/database.php";

if (isset($_POST['dataidgaji'])) {
    $nip = $_POST['dataidgaji'];

    // fungsi query untuk menampilkan data dari tabel barang
    $query = mysqli_query($mysqli, "SELECT SUM(if(keterangan=\"Seasson\",1,0)) AS seasson, SUM(if(keterangan=\"Waktu Tunggu\",1.6,0)) AS waktu FROM tb_absensi_guru WHERE nip='$nip' AND status='Sudah Dikonfirmasi'")
    or die('Ada kesalahan pada query tampil data gaji: ' . mysqli_error($mysqli));

    // tampilkan data
    $data = mysqli_fetch_assoc($query);

    $jml_sesion = $data['seasson'];
    $jml_waktu = $data['waktu'];
    $total_sesion = $jml_sesion + $jml_waktu;

    if ($total_sesion != '') {
        echo "<div class='form-group'>
                <label class='col-sm-2 control-label'>Jumlah Session</label>
                <div class='col-sm-5'>
                  <div class='input-group'>
                    <input type='text' class='form-control' id='jml_sesion' name='jml_sesion' value='$total_sesion' readonly>
                    <span class=\"input-group-addon\">Session</span>
                  </div>
                </div>
              </div>";
    } else {
        echo "<div class='form-group'>
                <label class='col-sm-2 control-label'>Jumlah Session</label>
                <div class='col-sm-5'>
                  <div class='input-group'>
                    <input type='text' class='form-control' id='jml_sesion' name='jml_sesion' value='Jumlah Session tidak ditemukan' readonly>
                    <span class=\"input-group-addon\">Session</span>
                  </div>
                </div>
              </div>";
    }
}
?> 