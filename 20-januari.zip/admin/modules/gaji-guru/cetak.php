<?php
/* panggil file database.php untuk koneksi ke database */
require_once "../../../config/database.php";
/* panggil file fungsi tambahan */
require_once "../../../config/fungsi_tanggal.php";
require_once "../../../config/fungsi_rupiah.php";

if (isset($_GET['id'])) {
    // fungsi query untuk menampilkan data dari tabel gaji_guru
    $query = mysqli_query($mysqli, "SELECT * FROM tb_gaji_guru as a INNER JOIN tb_guru as b
                                            ON a.nip=b.nip WHERE id_gaji_guru='$_GET[id]' ORDER BY a.id_gaji_guru DESC")
    or die('Ada kesalahan pada query tampil data gaji_guru : ' . mysqli_error($mysqli));
    $data = mysqli_fetch_assoc($query);

    $t_gaji_guru = $data['tanggal'];
    $tgl = explode('-', $t_gaji_guru);
    $tanggal = $tgl[2] . "-" . $tgl[1] . "-" . $tgl[0];

    $tahun = date('Y');
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Struk | Aplikasi Penggajian </title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="description" content="Aplikasi Penggajian PT. Citra Pesona Gemilang">
    <meta name="author" content="Wulan Pahira"/>

    <!-- favicon -->
    <link rel="shortcut icon" href="../../../assets/img/favicon.png"/>
</head>
<body>
<br>
<table>
    <tr>
        <td colspan="3" align="center"><b>Slip Gaji</b></td>
    </tr>
    <tr>
        <td colspan="3" align="center">PT. Citra Pesona Gemilang</td>
    </tr>
    <tr>
        <td colspan="3">------------------------------------------------</td>
    </tr>
    <tr>
        <td>ID Transaksi</td>
        <td>:</td>
        <td align="right"><?php echo $data['id_gaji_guru']; ?></td>
    </tr>
    <tr>
        <td>Bulan</td>
        <td>:</td>
        <td align="right"><?php echo $data['bulan']; ?><?php echo $tahun; ?></td>
    </tr>
    <tr>
        <td colspan="3">------------------------------------------------</td>
    </tr>
    <tr>
        <td>NIP</td>
        <td>:</td>
        <td align="right"><?php echo $data['nip']; ?></td>
    </tr>
    <tr>
        <td>Nama Lengkap</td>
        <td>:</td>
        <td align="right"><?php echo $data['nama_lengkap']; ?></td>
    </tr>
    <tr>
        <td colspan="3">------------------------------------------------</td>
    </tr>
    <tr>
        <td>Honor Sesion</td>
        <td>:</td>
        <td align="right"><?php echo format_rupiah($data['honor_sesion']); ?></td>
    </tr>
    <tr>
        <td>Jumlah Sesion</td>
        <td>:</td>
        <td align="right"><?php echo format_rupiah($data['jml_sesion']); ?></td>
    </tr>
    <tr>
        <td>Total Honor Sesion</td>
        <td>:</td>
        <td align="right"><?php echo format_rupiah($data['total_honor_sesion']); ?></td>
    </tr>
    <tr>
        <td>Honor Rapat</td>
        <td>:</td>
        <td align="right"><?php echo format_rupiah($data['honor_rapat']); ?></td>
    </tr>
    <tr>
        <td>Total Honor Sesion</td>
        <td>:</td>
        <td align="right"><?php echo format_rupiah($data['total_honor_sesion']); ?></td>
    </tr>
    <tr>
        <td>Subsidi DPLK</td>
        <td>:</td>
        <td align="right"><?php echo format_rupiah($data['subsidi_dplk']); ?></td>
    </tr>
    <tr>
        <td>Tambahan Transport</td>
        <td>:</td>
        <td align="right"><?php echo format_rupiah($data['tambahan_transport']); ?></td>
    </tr>
    <tr>
        <td>Total Gaji</td>
        <td>:</td>
        <td align="right"><?php echo format_rupiah($data['total_gaji']); ?></td>
    </tr>
    <tr>
        <td colspan="3">------------------------------------------------</td>
    </tr>
    <tr>
        <td>Potongan Kasbon</td>
        <td>:</td>
        <td align="right"><?php echo format_rupiah($data['pot_kasbon']); ?></td>
    </tr>
    <tr>
        <td>Potongan DPLK</td>
        <td>:</td>
        <td align="right"><?php echo format_rupiah($data['pot_dplk']); ?></td>
    </tr>
    <tr>
        <td>Potongan Lain-lain</td>
        <td>:</td>
        <td align="right"><?php echo format_rupiah($data['pot_lain']); ?></td>
    </tr>
    <tr>
        <td>Potongan PPH 21</td>
        <td>:</td>
        <td align="right"><?php echo format_rupiah($data['pot_pph21']); ?></td>
    </tr>
    <tr>
        <td colspan="3">------------------------------------------------</td>
    </tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr>
        <td align="center" colspan="3"><b>Total Gaji Diterima :
                Rp. <?php echo format_rupiah($data['total_gaji_diterima']); ?></b>
        </td>
    </tr>
    <tr>
        <td colspan="3">------------------------------------------------</td>
    </tr>
    <tr>
        <td align="center" colspan="3">Terima kasih</td>
    </tr>
</table>
</body>
</html>