<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        <i class="fa fa-check-square-o icon-title"></i> Data Gaji Staff
    </h1>

</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">

            <?php
            // fungsi untuk menampilkan pesan
            // jika alert = "" (kosong)
            // tampilkan pesan "" (kosong)
            if (empty($_GET['alert'])) {
                echo "";
            }
            // jika alert = 1
            // tampilkan pesan Sukses "Data gaji_staff baru berhasil disimpan"
            elseif ($_GET['alert'] == 1) {
                echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Sukses!</h4>
              Data gaji staff sudah diterima.
            </div>";
            }
            // jika alert = 2
            // tampilkan pesan Sukses "Data gaji_staff berhasil diubah"
            elseif ($_GET['alert'] == 2) {
                echo "<div class='alert alert-success alert-dismissable'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4>  <i class='icon fa fa-check-circle'></i> Sukses!</h4>
              Data gaji staff belum diterima.
            </div>";
            }
            ?>

            <div class="box box-primary">
                <div class="box-body">
                    <!-- tampilan tabel gaji_staff -->
                    <table id="dataTables1" class="table table-bordered table-striped table-hover">
                        <!-- tampilan tabel header -->
                        <thead>
                        <tr>
                            <th class="center">No.</th>
                            <th class="center">ID Transaksi</th>
                            <th class="center">Tanggal</th>
                            <th class="center">Bulan</th>
                            <th class="center">NIP</th>
                            <th class="center">Nama Lengkap</th>
                            <th class="center">Total Gaji</th>
                            <th class="center">Status</th>
                            <th></th>
                        </tr>
                        </thead>
                        <!-- tampilan tabel body -->
                        <tbody>
                        <?php
                        $no = 1;
                        // fungsi query untuk menampilkan data dari tabel gaji_staff
                        $query = mysqli_query($mysqli, "SELECT * FROM tb_gaji_staff as a INNER JOIN tb_staff as b
                                            ON a.nip=b.nip AND b.nip=$_SESSION[nip] ORDER BY a.id_gaji_staff DESC")
                        or die('Ada kesalahan pada query tampil Data Gaji Staff: ' . mysqli_error($mysqli));

                        // tampilkan data
                        while ($data = mysqli_fetch_assoc($query)) {
                            $t_gaji_staff = $data['tanggal'];
                            $exp = explode('-', $t_gaji_staff);
                            $tanggal_gaji_staff = $exp[2] . "-" . $exp[1] . "-" . $exp[0];

                            // menampilkan isi tabel dari database ke tabel di aplikasi
                            echo "<tr>
                      <td width='40' class='center'>$no</td>
                      <td width='80' class='center'>$data[id_gaji_staff]</td>
                      <td width='80' class='center'>$tanggal_gaji_staff</td>
                      <td width='40'>$data[bulan]</td>
                      <td width='80' class='center'>$data[nip]</td>
                      <td width='100' class='center'>$data[nama_lengkap]</td>
                      <td width='100' align='right'>" . format_rupiah($data['total_gaji_diterima']) . "</td>
                      <td width='100' class='center'>$data[status]</td>
                      <td class='center' width='100'>
                        <div>";

                            if ($data['status'] == 'Belum Diterima') { ?>
                                <a data-toggle="tooltip" data-placement="top" title="Konfirmasi" style="margin-right:5px"
                                   class="btn btn-success btn-sm"
                                   href="modules/gaji-staff/proses.php?act=off&id=<?php echo $data['id_gaji_staff']; ?>">
                                    <i style="color:#fff" class="glyphicon glyphicon-ok"></i>
                                </a>
                                <?php
                            } else { ?>
                                <a data-toggle="tooltip" data-placement="top" title="Batalkan" style="margin-right:5px"
                                   class="btn btn-danger btn-sm"
                                   href="modules/gaji-staff/proses.php?act=on&id=<?php echo $data['id_gaji_staff']; ?>">
                                    <i style="color:#fff" class="glyphicon glyphicon-remove"></i>
                                </a>
                                <?php
                            }
                            ?>
                            <a data-toggle="tooltip" data-placement="top" title="Cetak" class="btn btn-info btn-sm"
                               href="modules/gaji-staff/cetak.php?id=<?php echo $data['id_gaji_staff']; ?>"
                               target="_blank">
                                <i style="color:#fff" class="glyphicon glyphicon-print"></i>
                            </a>
                            <?php

                          echo " </div>
                      </td>
                    </tr>";
                            $no++;
                        }
                        ?>
                        </tbody>
                    </table>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div><!--/.col -->
    </div>   <!-- /.row -->
</section><!-- /.content