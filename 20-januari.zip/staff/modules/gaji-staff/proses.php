<?php
session_start();

// Panggil koneksi database.php untuk koneksi database
require_once "../../../config/database.php";

// fungsi untuk pengecekan status login user 
// jika user belum login, alihkan ke halaman login dan tampilkan pesan = 1
if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
    echo "<meta http-equiv='refresh' content='0; url=login.php?alert=1'>";
} // jika user sudah login, maka jalankan perintah untuk insert, update, dan delete
else {
    if ($_GET['act'] == 'insert') {
        if (isset($_POST['simpan'])) {
            // ambil data hasil submit dari form
            $id_gaji_staff = mysqli_real_escape_string($mysqli, trim($_POST['id_gaji_staff']));
            $nip = mysqli_real_escape_string($mysqli, trim($_POST['nip']));
            $t_gaji_staff = mysqli_real_escape_string($mysqli, trim($_POST['tanggal']));
            $exp = explode('-', $t_gaji_staff);
            $tanggal = $exp[2] . "-" . $exp[1] . "-" . $exp[0];
            $bulan = mysqli_real_escape_string($mysqli, trim($_POST['bulan']));

            $gaji_pokok = str_replace('.', '', trim($_POST['gaji_pokok']));
            $uang_hadir = str_replace('.', '', trim($_POST['uang_hadir']));
            $jml_hadir = str_replace('.', '', trim($_POST['jml_hadir']));
            $total_uang_hadir = str_replace('.', '', trim($_POST['total_uang_hadir']));
            $honor_tambahan = str_replace('.', '', trim($_POST['honor_tambahan']));
            $total_gaji = str_replace('.', '', trim($_POST['total_gaji']));

            $pot_kasbon = str_replace('.', '', trim($_POST['pot_kasbon']));
            $pot_dplk = str_replace('.', '', trim($_POST['pot_dplk']));
            $pot_lain = str_replace('.', '', trim($_POST['pot_lain']));
            $pot_bpjs = str_replace('.', '', trim($_POST['pot_bpjs']));
            $pot_pph21 = str_replace('.', '', trim($_POST['pot_pph21']));
            $total_gaji_diterima = str_replace('.', '', trim($_POST['total_gaji_diterima']));

            // perintah query untuk menyimpan data ke tabel gaji_staff
            $query = mysqli_query($mysqli, "INSERT INTO tb_gaji_staff(id_gaji_staff,nip,tanggal,bulan,gaji_pokok,
                                                    uang_hadir,jml_hadir,total_uang_hadir,honor_tambahan,total_gaji,pot_kasbon,pot_dplk,pot_lain,
                                                    pot_bpjs,pot_pph21,total_gaji_diterima)
                                            VALUES('$id_gaji_staff','$nip','$tanggal ','$bulan','$gaji_pokok','$uang_hadir','$jml_hadir',
                                                    '$total_uang_hadir','$honor_tambahan','$total_gaji','$pot_kasbon','$pot_dplk','$pot_lain',
                                                    '$pot_bpjs','$pot_pph21','$total_gaji_diterima')")
            or die('Ada kesalahan pada query insert : ' . mysqli_error($mysqli));

            // cek query
            if ($query) {
                // jika berhasil tampilkan pesan berhasil simpan data
                header("location: ../../main.php?module=gaji_staff&alert=1");
            }
        }
    } elseif ($_GET['act'] == 'update') {
        if (isset($_POST['simpan'])) {
            if (isset($_POST['id_gaji_staff'])) {
                // ambil data hasil submit dari form
                $id_gaji_staff = mysqli_real_escape_string($mysqli, trim($_POST['id_gaji_staff']));
                $nip = mysqli_real_escape_string($mysqli, trim($_POST['nip']));
                $t_gaji_staff = mysqli_real_escape_string($mysqli, trim($_POST['tanggal']));
                $exp = explode('-', $t_gaji_staff);
                $tanggal = $exp[2] . "-" . $exp[1] . "-" . $exp[0];
                $bulan = mysqli_real_escape_string($mysqli, trim($_POST['bulan']));

                $gaji_pokok = str_replace('.', '', trim($_POST['gaji_pokok']));
                $uang_hadir = str_replace('.', '', trim($_POST['uang_hadir']));
                $jml_hadir = str_replace('.', '', trim($_POST['jml_hadir']));
                $total_uang_hadir = str_replace('.', '', trim($_POST['total_uang_hadir']));
                $honor_tambahan = str_replace('.', '', trim($_POST['honor_tambahan']));
                $total_gaji = str_replace('.', '', trim($_POST['total_gaji']));

                $pot_kasbon = str_replace('.', '', trim($_POST['pot_kasbon']));
                $pot_dplk = str_replace('.', '', trim($_POST['pot_dplk']));
                $pot_lain = str_replace('.', '', trim($_POST['pot_lain']));
                $pot_bpjs = str_replace('.', '', trim($_POST['pot_bpjs']));
                $pot_pph21 = str_replace('.', '', trim($_POST['pot_pph21']));
                $total_gaji_diterima = str_replace('.', '', trim($_POST['total_gaji_diterima']));

                $query = mysqli_query($mysqli, "UPDATE tb_gaji_staff SET nip='$nip',
                                                                            tanggal='$tanggal',
                                                                            bulan='$bulan',
                                                                            gaji_pokok='$gaji_pokok',
                                                                            uang_hadir='$uang_hadir',
                                                                            jml_hadir='$jml_hadir',
                                                                            total_uang_hadir='$total_uang_hadir',
                                                                            honor_tambahan='$honor_tambahan',
                                                                            total_gaji='$total_gaji',
                                                                            pot_kasbon='$pot_kasbon',
                                                                            pot_dplk='$pot_dplk',
                                                                            pot_lain='$pot_lain',
                                                                            pot_bpjs='$pot_bpjs',
                                                                            pot_pph21='$pot_pph21',
                                                                            total_gaji_diterima='$total_gaji_diterima'                                                                            
                                                            WHERE id_gaji_staff='$id_gaji_staff'")
                or die('Ada kesalahan pada query update : ' . mysqli_error($mysqli));

                // cek query
                if ($query) {
                    // jika berhasil tampilkan pesan berhasil update data
                    header("location: ../../main.php?module=gaji_staff&alert=2");
                }
            }
        }
    } elseif ($_GET['act'] == 'delete') {
        if (isset($_GET['id'])) {
            $id_gaji_staff = $_GET['id'];

            // perintah query untuk menghapus data pada tabel gaji_staff
            $query = mysqli_query($mysqli, "DELETE FROM tb_gaji_staff WHERE id_gaji_staff='$id_gaji_staff'")
            or die('Ada kesalahan pada query delete : ' . mysqli_error($mysqli));

            // cek hasil query
            if ($query) {
                // jika berhasil tampilkan pesan berhasil delete data
                header("location: ../../main.php?module=gaji_staff&alert=3");
            }
        }
    }
    // update status menjadi Sudah Dikonfirmasi
    elseif ($_GET['act'] == 'off') {
        if (isset($_GET['id'])) {
            // ambil data hasil submit dari form
            $id_gaji_staff = $_GET['id'];
            $status = "Sudah Diterima";

            // perintah query untuk mengubah data pada tabel users
            $query = mysqli_query($mysqli, "UPDATE tb_gaji_staff SET status  = '$status'
                                                          WHERE id_gaji_staff = '$id_gaji_staff'")
            or die('Ada kesalahan pada query update status on : ' . mysqli_error($mysqli));

            // cek query
            if ($query) {
                // jika berhasil tampilkan pesan berhasil update data
                header("location: ../../main.php?module=gaji&alert=1");
            }
        }
    }
// update status menjadi Menunggu Konfirmasi
    elseif ($_GET['act'] == 'on') {
        if (isset($_GET['id'])) {
            // ambil data hasil submit dari form
            $id_gaji_staff = $_GET['id'];
            $status = "Belum Diterima";

            // perintah query untuk mengubah data pada tabel users
            $query = mysqli_query($mysqli, "UPDATE tb_gaji_staff SET status  = '$status'
                                                          WHERE id_gaji_staff = '$id_gaji_staff'")
            or die('Ada kesalahan pada query update status on : ' . mysqli_error($mysqli));

            // cek query
            if ($query) {
                // jika berhasil tampilkan pesan berhasil update data
                header("location: ../../main.php?module=gaji&alert=1");
            }
        }
    }

}
?>