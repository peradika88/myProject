<!-- sidebar menu start -->
<ul class="sidebar-menu">
    <li class="header">MAIN MENU</li>

    <?php
    // fungsi untuk pengecekan menu aktif
    // jika menu home dipilih, menu home aktif
    if ($_GET["module"] == "home") { ?>
        <li class="active">
            <a href="?module=home"><i class="fa fa-home"></i> Beranda </a>
        </li>
        <?php
    } // jika tidak, menu home tidak aktif
    else { ?>
        <li>
            <a href="?module=home"><i class="fa fa-home"></i> Beranda </a>
        </li>
        <?php
    }

    // jika menu gaji dipilih, menu gaji aktif
    if ($_GET["module"] == "gaji") { ?>
        <li class="active">
            <a href="?module=gaji"><i class="fa fa-group"></i> Rincian Gaji</a>
        </li>
        <?php
    } // jika tidak, menu gaji tidak aktif
    else { ?>
        <li>
            <a href="?module=gaji"><i class="fa fa-group"></i> Rincian Gaji</a>
        </li>
        <?php
    }

    ?>
</ul>
<!--sidebar menu end-->
