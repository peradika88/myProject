<?php
/* panggil file database.php untuk koneksi ke database */
require_once "../config/database.php";
/* panggil file fungsi tambahan */
require_once "../config/fungsi_tanggal.php";
require_once "../config/fungsi_rupiah.php";

// fungsi untuk pengecekan status login user 
// jika user belum login, alihkan ke halaman login dan tampilkan message = 1
if (empty($_SESSION['nip']) && empty($_SESSION['password'])) {
    echo "<meta http-equiv='refresh' content='0; url=login.php?alert=1'>";
} // jika user sudah login, maka jalankan perintah untuk pemanggilan file halaman konten
else {
    // jika halaman konten yang dipilih home, panggil file view home
    if ($_GET['module'] == 'home') {
        include "modules/beranda/view.php";
    }

    elseif ($_GET['module'] == 'gaji') {
        include "modules/gaji-staff/view.php";
    }

    elseif ($_GET['module'] == 'password') {
        include "modules/password/view.php";
    }

}
?>