<?php
/* panggil file database.php untuk koneksi ke database */
require_once "../config/database.php";

// fungsi query untuk menampilkan data dari tabel user
$query = mysqli_query($mysqli, "SELECT nip, nama_lengkap, foto FROM tb_staff WHERE nip='$_SESSION[nip]'")
or die('Ada kesalahan pada query tampil Manajemen Staff: ' . mysqli_error($mysqli));

// tampilkan data
$data = mysqli_fetch_assoc($query);
?>

<li class="dropdown user user-menu">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
        <!-- User image -->

        <?php
        if ($data['foto'] == "") { ?>
            <img src="images/staff/staff-default.png" class="user-image" alt="User Image"/>
            <?php
        } else { ?>
            <img src="images/staff/<?php echo $data['foto']; ?>" class="user-image" alt="User Image"/>
            <?php
        }
        ?>

        <span class="hidden-xs"><?php echo $data['nama_lengkap']; ?> <i style="margin-left:5px"
                                                                        class="fa fa-angle-down"></i></span>
    </a>

    <ul class="dropdown-menu">
        <!-- User image -->
        <li class="user-header">

            <?php
            if ($data['foto'] == "") { ?>
                <img src="images/staff/staff-default.png" class="img-circle" alt="User Image"/>
                <?php
            } else { ?>
                <img src="images/staff/<?php echo $data['foto']; ?>" class="img-circle" alt="User Image"/>
                <?php
            }
            ?>

            <p>
                <?php echo $data['nama_lengkap']; ?>
                <small><?php echo $data['nip']; ?></small>
            </p>
        </li>

        <!-- Menu Footer-->
        <li class="user-footer">
            <div class="pull-left">
                <a style="width:120px" href="?module=password" class="btn btn-default btn-flat">Ganti Password</a>
            </div>

            <div class="pull-right">
                <a style="width:80px" data-toggle="modal" href="#logout" class="btn btn-default btn-flat">Logout</a>
            </div>
        </li>
    </ul>
</li>