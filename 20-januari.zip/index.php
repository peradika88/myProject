<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Selamat Datang di Aplikasi E-Report</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="description" content="Aplikasi Penggajian PT. Citra Pesona Gemilang">
    <meta name="author" content="Wulan Pahira"/>

    <!-- favicon -->
    <link rel="shortcut icon" href="assets/img/favicon.png"/>

    <!-- Bootstrap 3.3.2 -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <!-- FontAwesome 4.3.0 -->
    <link href="assets/plugins/font-awesome-4.6.3/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
    <!-- Theme style -->
    <link href="assets/css/AdminLTE.min.css" rel="stylesheet" type="text/css"/>
    <!-- AdminLTE Skins. Choose a skin from the css/skins folder instead of downloading all of them to reduce the load. -->
    <link href="assets/css/skins/skin-blue.min.css" rel="stylesheet" type="text/css"/>
    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet" type="text/css"/>
</head>
<body class="skin-blue fixed">
<div class="wrapper">

    <header class="main-header">
        <!-- Logo -->
        <a href="index.php" class="logo">E-Report</a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                <span class="sr-only">Toggle navigation</span>
            </a>
            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">
                </ul>
            </div>
        </nav>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
            <ul class="sidebar-menu">
                <li class="header">MAIN MENU</li>
                <li class="active">
                    <a href="login.php" target="_blank"><i class="fa fa-lock"></i> Login </a>
                </li>
            </ul>

        </section>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper" style="background-image: bg.png">

        <!-- Main content -->
        <section class="content">
            <br><br>
            <div style="text-align: center" class="row">
                <div class="col-lg-12 col-xs-12">
                    <div style="margin-right: 150px; margin-left: 150px">
                        <h1>SELAMAT DATANG DI SISTEM E-REPORT</h1>
                        <h1>PT. CATUR MITRA SEJATI SENTOSA</h1>
                    </div>
                    <br>
                    <img src="bglogo.png">
                    <br><br>
                    <div style="margin-right: 150px; margin-left: 150px">
                        <h2>Jl. Boulevard Raya Gading Serpong Blok Mitra 10, Curug Sangereng, Kec. Klp. Dua, <br>Tangerang, Banten 15820</h2>
                    </div>
                    <br>
                </div>
            </div>
        </section><!-- /.content -->

    </div><!-- /.content-wrapper -->

    <footer class="main-footer">
        <div align="right"><strong>&copy; 2019 Winalda Pradika</strong></div>
    </footer>
</div><!-- ./wrapper -->

<!-- jQuery 2.1.3 -->
<script src="assets/plugins/jQuery/jQuery-2.1.3.min.js"></script>
<!-- Bootstrap 3.3.2 JS -->
<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
<!-- AdminLTE App -->
<script src="assets/js/app.min.js" type="text/javascript"></script>

</body>
</html>