<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login | Aplikasi E-Report</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="description" content="Aplikasi Penggajian PT. Citra Pesona Gemilang">
    <meta name="author" content="Wulan Pahira"/>

    <!-- favicon -->
    <link rel="shortcut icon" href="assets/img/favicon.png"/>

    <!-- Bootstrap 3.3.2 -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <!-- Font Awesome Icons -->
    <link href="assets/plugins/font-awesome-4.6.3/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
    <!-- Theme style -->
    <link href="assets/css/AdminLTE.min.css" rel="stylesheet" type="text/css"/>
    <!-- iCheck -->
    <link href="assets/plugins/iCheck/square/blue.css" rel="stylesheet" type="text/css"/>
    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet" type="text/css"/>

</head>
<body class="login-page bg-login">
<div class="login-box">
    <?php
    /* panggil file database.php untuk koneksi ke database */
    require_once "config/database.php";
    // fungsi query untuk menampilkan data dari tabel about
    $query = mysqli_query($mysqli, "SELECT isi_pengumuman FROM tb_pengumuman WHERE id_pengumuman='1'")
    or die('Ada kesalahan pada query tampil data pengumuman : ' . mysqli_error($mysqli));

    $data = mysqli_fetch_assoc($query);
    ?>
    <div style="color:#ffffff" class="login-logo">
        Aplikasi<b> E-Report</b>
    </div><!-- /.login-logo -->
    
    <?php
    // fungsi untuk menampilkan pesan
    // jika alert = "" (kosong)
    // tampilkan pesan "" (kosong)
    if (empty($_GET['alert'])) {
        echo "";
    }
    // jika alert = 1
    // tampilkan pesan Gagal "Username atau Password salah, cek kembali Username dan Password Anda"
    elseif ($_GET['alert'] == 1) {
        echo "<div class='alert alert-danger alert-dismissable'>
                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                <h4>  <i class='icon fa fa-times-circle'></i> Gagal Login!</h4>
                Username atau Password salah, cek kembali Username dan Password Anda.
              </div>";
    }
    // jika alert = 2
    // tampilkan pesan Sukses "Anda telah berhasil logout"
    elseif ($_GET['alert'] == 2) {
        echo "<div class='alert alert-success alert-dismissable'>
                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                <h4>  <i class='icon fa fa-check-circle'></i> Sukses!</h4>
                Anda telah berhasil logout.
              </div>";
    }
    ?>

    <div class="login-box-body">
        <p class="login-box-msg"><i class="fa fa-user icon-title"></i> Silahkan Login Sebagai :</p>
        <br/>
        <div align="center">

            <a class="btn btn-app alert-info" href="admin">
                <i class="fa fa-user"></i> Admin
            </a>
            <a class="btn btn-app alert-info" href="admin">
                <i class="fa fa-user"></i> General Manager
            </a>
            <a class="btn btn-app alert-info" href="koordinator">
                <i class="fa fa-user"></i> Region Manager
            </a>
            <a class="btn btn-app alert-info"  href="guru">
                <i class="fa fa-user"></i> Store Manager
            </a>
            <a class="btn btn-app alert-info" href="guru">
                <i class="fa fa-user"></i> Deputy Manager
            </a>
            <a class="btn btn-app alert-info" href="staff">
                <i class="fa fa-user"></i> Guest
            </a>
        </div>

        <hr/>
        <p align="center"> &copy; 2019 PT. CATUR MITRA SEJATI SENTOSA.</p>

    </div><!-- /.login-box-body -->
</div><!-- /.login-box -->

<!-- jQuery 2.1.3 -->
<script src="assets/plugins/jQuery/jQuery-2.1.3.min.js"></script>
<!-- Bootstrap 3.3.2 JS -->
<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

</body>
</html>